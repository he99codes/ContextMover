import { s as startSessionCapture, w as waitForAnyElement, a as setPromptInputValue, e as extractMessageContent } from './shared-kgClQg5h.js';
import './session-id-BlkLb76o.js';

console.log("[ContextForge] Perplexity content script loaded");
function scrapeMessages() {
  const collected = [];
  const hasAsst = () => collected.some((e) => e.role === "assistant");
  {
    const els = [...document.querySelectorAll("[data-message-role]")].filter((el) => !el.parentElement?.closest("[data-message-role]"));
    for (const el of els) {
      const role = el.dataset.messageRole;
      if (role === "user" || role === "assistant") collected.push({ el, role });
    }
    console.log(`[ContextForge:perplexity] A data-message-role: ${collected.length}`);
  }
  if (!hasAsst()) {
    const userSel = '[class*="UserMessage"], [class*="user-query"], [class*="query-bubble"], [class*="user-message"]';
    const asstSel = '[class*="AnswerText"], [class*="answer-text"], [class*="model-answer"], [class*="assistant-message"], [class*="prose"][class*="answer"]';
    const userEls = [...document.querySelectorAll(userSel)].filter((el) => !el.parentElement?.closest(userSel));
    const asstEls = [...document.querySelectorAll(asstSel)].filter((el) => !el.parentElement?.closest(asstSel));
    for (const el of userEls) collected.push({ el, role: "user" });
    for (const el of asstEls) collected.push({ el, role: "assistant" });
    console.log(`[ContextForge:perplexity] B class-substr: user=${userEls.length} asst=${asstEls.length}`);
  }
  if (!hasAsst()) {
    const threadSel = '[class*="thread-item"], [class*="ThreadItem"], [class*="conversation-turn"], [class*="ConversationTurn"]';
    const turns = [...document.querySelectorAll(threadSel)].filter((el) => !el.parentElement?.closest(threadSel));
    for (const turn of turns) {
      const queryEl = turn.querySelector('[class*="query"], [class*="Query"], [class*="user"]');
      const answerEl = turn.querySelector('[class*="answer"], [class*="Answer"], [class*="markdown"], .prose');
      if (queryEl) collected.push({ el: queryEl, role: "user" });
      if (answerEl) collected.push({ el: answerEl, role: "assistant" });
    }
    console.log(`[ContextForge:perplexity] C thread-items: ${turns.length} turns`);
  }
  if (!hasAsst()) {
    const proseEls = [...document.querySelectorAll('.prose, [class*="markdown"], [class*="Markdown"]')].filter((el) => !el.parentElement?.closest('.prose, [class*="markdown"]'));
    for (const el of proseEls) {
      const text = (el.textContent ?? "").trim();
      if (text.length > 30) collected.push({ el, role: "assistant" });
    }
    console.log(`[ContextForge:perplexity] D prose/markdown: ${proseEls.length}`);
  }
  if (collected.length === 0) {
    const classHits = /* @__PURE__ */ new Map();
    document.querySelectorAll("*").forEach((el) => {
      el.classList.forEach((c) => {
        if (/query|answer|message|thread|turn|user|assistant|perplexity|prose/i.test(c)) {
          classHits.set(c, (classHits.get(c) ?? 0) + 1);
        }
      });
    });
    const top = [...classHits.entries()].sort((a2, b) => b[1] - a2[1]).slice(0, 20);
    console.warn("[ContextForge:perplexity] NO messages found. Top candidate classes:", top);
    return [];
  }
  collected.sort((a2, b) => {
    const pos = a2.el.compareDocumentPosition(b.el);
    return pos & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
  });
  const messages = [];
  for (const { el, role } of collected) {
    const content = extractMessageContent(el);
    if (content) messages.push({ role, content, timestamp: Date.now() });
    else console.warn(`[ContextForge:perplexity] empty content for role=${role}`);
  }
  const u = messages.filter((m) => m.role === "user").length;
  const a = messages.filter((m) => m.role === "assistant").length;
  console.log(`[ContextForge:perplexity] FINAL: ${messages.length} msgs (user=${u} asst=${a})`);
  if (a === 0 && u > 0) console.error("[ContextForge:perplexity] ASSISTANT MESSAGES MISSING");
  return messages;
}
startSessionCapture({
  platform: "perplexity",
  selectorOrElement: "main",
  scrapeMessages
});
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "INJECT_CONTEXT" && msg.platform === "perplexity") {
    void injectIntoPerplexityInput(msg.prompt).then(sendResponse);
    return true;
  }
});
async function injectIntoPerplexityInput(text) {
  const input = await waitForAnyElement([
    "textarea[placeholder*='Ask']",
    "textarea[placeholder*='ask']",
    "textarea[placeholder*='Search']",
    "textarea[placeholder*='search']",
    '[contenteditable="true"][role="textbox"]',
    ".ProseMirror[contenteditable='true']",
    "textarea:not([readonly])",
    '[contenteditable="true"]'
  ]);
  if (!input) return { ok: false, error: "Perplexity input not found. Make sure a conversation is open." };
  if (!setPromptInputValue(input, text)) return { ok: false, error: "Perplexity input did not accept the text." };
  return { ok: true };
}
