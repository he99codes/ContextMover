const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/transformers-DmVREIS2.js","assets/__vite-browser-external-Bhan8LHw.js","assets/_commonjsHelpers-Dj2_voLF.js"])))=>i.map(i=>d[i]);
const scriptRel = 'modulepreload';const assetsURL = function(dep) { return "/"+dep };const seen = {};const __vitePreload = function preload(baseModule, deps, importerUrl) {
  let promise = Promise.resolve();
  if (true && deps && deps.length > 0) {
    document.getElementsByTagName("link");
    const cspNonceMeta = document.querySelector(
      "meta[property=csp-nonce]"
    );
    const cspNonce = cspNonceMeta?.nonce || cspNonceMeta?.getAttribute("nonce");
    promise = Promise.allSettled(
      deps.map((dep) => {
        dep = assetsURL(dep);
        if (dep in seen) return;
        seen[dep] = true;
        const isCss = dep.endsWith(".css");
        const cssSelector = isCss ? '[rel="stylesheet"]' : "";
        if (document.querySelector(`link[href="${dep}"]${cssSelector}`)) {
          return;
        }
        const link = document.createElement("link");
        link.rel = isCss ? "stylesheet" : scriptRel;
        if (!isCss) {
          link.as = "script";
        }
        link.crossOrigin = "";
        link.href = dep;
        if (cspNonce) {
          link.setAttribute("nonce", cspNonce);
        }
        document.head.appendChild(link);
        if (isCss) {
          return new Promise((res, rej) => {
            link.addEventListener("load", res);
            link.addEventListener(
              "error",
              () => rej(new Error(`Unable to preload CSS for ${dep}`))
            );
          });
        }
      })
    );
  }
  function handlePreloadError(err) {
    const e = new Event("vite:preloadError", {
      cancelable: true
    });
    e.payload = err;
    window.dispatchEvent(e);
    if (!e.defaultPrevented) {
      throw err;
    }
  }
  return promise.then((res) => {
    for (const item of res || []) {
      if (item.status !== "rejected") continue;
      handlePreloadError(item.reason);
    }
    return baseModule().catch(handlePreloadError);
  });
};

const instanceOfAny = (object, constructors) => constructors.some((c) => object instanceof c);

let idbProxyableTypes;
let cursorAdvanceMethods;
// This is a function to prevent it throwing up in node environments.
function getIdbProxyableTypes() {
    return (idbProxyableTypes ||
        (idbProxyableTypes = [
            IDBDatabase,
            IDBObjectStore,
            IDBIndex,
            IDBCursor,
            IDBTransaction,
        ]));
}
// This is a function to prevent it throwing up in node environments.
function getCursorAdvanceMethods() {
    return (cursorAdvanceMethods ||
        (cursorAdvanceMethods = [
            IDBCursor.prototype.advance,
            IDBCursor.prototype.continue,
            IDBCursor.prototype.continuePrimaryKey,
        ]));
}
const transactionDoneMap = new WeakMap();
const transformCache = new WeakMap();
const reverseTransformCache = new WeakMap();
function promisifyRequest(request) {
    const promise = new Promise((resolve, reject) => {
        const unlisten = () => {
            request.removeEventListener('success', success);
            request.removeEventListener('error', error);
        };
        const success = () => {
            resolve(wrap(request.result));
            unlisten();
        };
        const error = () => {
            reject(request.error);
            unlisten();
        };
        request.addEventListener('success', success);
        request.addEventListener('error', error);
    });
    // This mapping exists in reverseTransformCache but doesn't exist in transformCache. This
    // is because we create many promises from a single IDBRequest.
    reverseTransformCache.set(promise, request);
    return promise;
}
function cacheDonePromiseForTransaction(tx) {
    // Early bail if we've already created a done promise for this transaction.
    if (transactionDoneMap.has(tx))
        return;
    const done = new Promise((resolve, reject) => {
        const unlisten = () => {
            tx.removeEventListener('complete', complete);
            tx.removeEventListener('error', error);
            tx.removeEventListener('abort', error);
        };
        const complete = () => {
            resolve();
            unlisten();
        };
        const error = () => {
            reject(tx.error || new DOMException('AbortError', 'AbortError'));
            unlisten();
        };
        tx.addEventListener('complete', complete);
        tx.addEventListener('error', error);
        tx.addEventListener('abort', error);
    });
    // Cache it for later retrieval.
    transactionDoneMap.set(tx, done);
}
let idbProxyTraps = {
    get(target, prop, receiver) {
        if (target instanceof IDBTransaction) {
            // Special handling for transaction.done.
            if (prop === 'done')
                return transactionDoneMap.get(target);
            // Make tx.store return the only store in the transaction, or undefined if there are many.
            if (prop === 'store') {
                return receiver.objectStoreNames[1]
                    ? undefined
                    : receiver.objectStore(receiver.objectStoreNames[0]);
            }
        }
        // Else transform whatever we get back.
        return wrap(target[prop]);
    },
    set(target, prop, value) {
        target[prop] = value;
        return true;
    },
    has(target, prop) {
        if (target instanceof IDBTransaction &&
            (prop === 'done' || prop === 'store')) {
            return true;
        }
        return prop in target;
    },
};
function replaceTraps(callback) {
    idbProxyTraps = callback(idbProxyTraps);
}
function wrapFunction(func) {
    // Due to expected object equality (which is enforced by the caching in `wrap`), we
    // only create one new func per func.
    // Cursor methods are special, as the behaviour is a little more different to standard IDB. In
    // IDB, you advance the cursor and wait for a new 'success' on the IDBRequest that gave you the
    // cursor. It's kinda like a promise that can resolve with many values. That doesn't make sense
    // with real promises, so each advance methods returns a new promise for the cursor object, or
    // undefined if the end of the cursor has been reached.
    if (getCursorAdvanceMethods().includes(func)) {
        return function (...args) {
            // Calling the original function with the proxy as 'this' causes ILLEGAL INVOCATION, so we use
            // the original object.
            func.apply(unwrap(this), args);
            return wrap(this.request);
        };
    }
    return function (...args) {
        // Calling the original function with the proxy as 'this' causes ILLEGAL INVOCATION, so we use
        // the original object.
        return wrap(func.apply(unwrap(this), args));
    };
}
function transformCachableValue(value) {
    if (typeof value === 'function')
        return wrapFunction(value);
    // This doesn't return, it just creates a 'done' promise for the transaction,
    // which is later returned for transaction.done (see idbObjectHandler).
    if (value instanceof IDBTransaction)
        cacheDonePromiseForTransaction(value);
    if (instanceOfAny(value, getIdbProxyableTypes()))
        return new Proxy(value, idbProxyTraps);
    // Return the same value back if we're not going to transform it.
    return value;
}
function wrap(value) {
    // We sometimes generate multiple promises from a single IDBRequest (eg when cursoring), because
    // IDB is weird and a single IDBRequest can yield many responses, so these can't be cached.
    if (value instanceof IDBRequest)
        return promisifyRequest(value);
    // If we've already transformed this value before, reuse the transformed value.
    // This is faster, but it also provides object equality.
    if (transformCache.has(value))
        return transformCache.get(value);
    const newValue = transformCachableValue(value);
    // Not all types are transformed.
    // These may be primitive types, so they can't be WeakMap keys.
    if (newValue !== value) {
        transformCache.set(value, newValue);
        reverseTransformCache.set(newValue, value);
    }
    return newValue;
}
const unwrap = (value) => reverseTransformCache.get(value);

/**
 * Open a database.
 *
 * @param name Name of the database.
 * @param version Schema version.
 * @param callbacks Additional callbacks.
 */
function openDB(name, version, { blocked, upgrade, blocking, terminated } = {}) {
    const request = indexedDB.open(name, version);
    const openPromise = wrap(request);
    if (upgrade) {
        request.addEventListener('upgradeneeded', (event) => {
            upgrade(wrap(request.result), event.oldVersion, event.newVersion, wrap(request.transaction), event);
        });
    }
    if (blocked) {
        request.addEventListener('blocked', (event) => blocked(
        // Casting due to https://github.com/microsoft/TypeScript-DOM-lib-generator/pull/1405
        event.oldVersion, event.newVersion, event));
    }
    openPromise
        .then((db) => {
        if (terminated)
            db.addEventListener('close', () => terminated());
        if (blocking) {
            db.addEventListener('versionchange', (event) => blocking(event.oldVersion, event.newVersion, event));
        }
    })
        .catch(() => { });
    return openPromise;
}

const readMethods = ['get', 'getKey', 'getAll', 'getAllKeys', 'count'];
const writeMethods = ['put', 'add', 'delete', 'clear'];
const cachedMethods = new Map();
function getMethod(target, prop) {
    if (!(target instanceof IDBDatabase &&
        !(prop in target) &&
        typeof prop === 'string')) {
        return;
    }
    if (cachedMethods.get(prop))
        return cachedMethods.get(prop);
    const targetFuncName = prop.replace(/FromIndex$/, '');
    const useIndex = prop !== targetFuncName;
    const isWrite = writeMethods.includes(targetFuncName);
    if (
    // Bail if the target doesn't exist on the target. Eg, getAll isn't in Edge.
    !(targetFuncName in (useIndex ? IDBIndex : IDBObjectStore).prototype) ||
        !(isWrite || readMethods.includes(targetFuncName))) {
        return;
    }
    const method = async function (storeName, ...args) {
        // isWrite ? 'readwrite' : undefined gzipps better, but fails in Edge :(
        const tx = this.transaction(storeName, isWrite ? 'readwrite' : 'readonly');
        let target = tx.store;
        if (useIndex)
            target = target.index(args.shift());
        // Must reject if op rejects.
        // If it's a write operation, must reject if tx.done rejects.
        // Must reject with op rejection first.
        // Must resolve with op value.
        // Must handle both promises (no unhandled rejections)
        return (await Promise.all([
            target[targetFuncName](...args),
            isWrite && tx.done,
        ]))[0];
    };
    cachedMethods.set(prop, method);
    return method;
}
replaceTraps((oldTraps) => ({
    ...oldTraps,
    get: (target, prop, receiver) => getMethod(target, prop) || oldTraps.get(target, prop, receiver),
    has: (target, prop) => !!getMethod(target, prop) || oldTraps.has(target, prop),
}));

const advanceMethodProps = ['continue', 'continuePrimaryKey', 'advance'];
const methodMap = {};
const advanceResults = new WeakMap();
const ittrProxiedCursorToOriginalProxy = new WeakMap();
const cursorIteratorTraps = {
    get(target, prop) {
        if (!advanceMethodProps.includes(prop))
            return target[prop];
        let cachedFunc = methodMap[prop];
        if (!cachedFunc) {
            cachedFunc = methodMap[prop] = function (...args) {
                advanceResults.set(this, ittrProxiedCursorToOriginalProxy.get(this)[prop](...args));
            };
        }
        return cachedFunc;
    },
};
async function* iterate(...args) {
    // tslint:disable-next-line:no-this-assignment
    let cursor = this;
    if (!(cursor instanceof IDBCursor)) {
        cursor = await cursor.openCursor(...args);
    }
    if (!cursor)
        return;
    cursor = cursor;
    const proxiedCursor = new Proxy(cursor, cursorIteratorTraps);
    ittrProxiedCursorToOriginalProxy.set(proxiedCursor, cursor);
    // Map this double-proxy back to the original, so other cursor methods work.
    reverseTransformCache.set(proxiedCursor, unwrap(cursor));
    while (cursor) {
        yield proxiedCursor;
        // If one of the advancing methods was not called, call continue().
        cursor = await (advanceResults.get(proxiedCursor) || cursor.continue());
        advanceResults.delete(proxiedCursor);
    }
}
function isIteratorProp(target, prop) {
    return ((prop === Symbol.asyncIterator &&
        instanceOfAny(target, [IDBIndex, IDBObjectStore, IDBCursor])) ||
        (prop === 'iterate' && instanceOfAny(target, [IDBIndex, IDBObjectStore])));
}
replaceTraps((oldTraps) => ({
    ...oldTraps,
    get(target, prop, receiver) {
        if (isIteratorProp(target, prop))
            return iterate;
        return oldTraps.get(target, prop, receiver);
    },
    has(target, prop) {
        return isIteratorProp(target, prop) || oldTraps.has(target, prop);
    },
}));

const ATTENTION_DB_NAME = "contextforge-attention";
const ATTENTION_DB_VERSION = 1;
const CHUNKS_STORE = "ae_chunks";
const STRUCTURE_STORE = "ae_structure";
const SESSIONS_META_STORE = "ae_sessions_meta";
const STRUCTURE_KEY = "singleton";
const MODEL_ID = "Xenova/all-MiniLM-L6-v2";
const EMBEDDING_DIM = 384;
const MAX_CHUNKS_PER_SESSION = 500;
const BATCH_SIZE = 32;
const SEARCH_TOP_K = 20;
const THRESHOLDS = { light: 0.4, strict: 0.7 };
const TAG = "[ContextForge:attention-engine]";
const GRAMMAR_FILE_MAP = {
  typescript: "tree-sitter-typescript.wasm",
  tsx: "tree-sitter-tsx.wasm",
  javascript: "tree-sitter-javascript.wasm",
  jsx: "tree-sitter-javascript.wasm",
  python: "tree-sitter-python.wasm",
  rust: "tree-sitter-rust.wasm",
  go: "tree-sitter-go.wasm"
};
function grammarUrl(lang) {
  const file = GRAMMAR_FILE_MAP[lang] ?? `tree-sitter-${lang}.wasm`;
  if (typeof chrome !== "undefined" && chrome.runtime?.getURL) {
    return chrome.runtime.getURL(`grammars/${file}`);
  }
  return `/grammars/${file}`;
}
class AttentionEngine {
  extractor = null;
  idb = null;
  appStructure = null;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  tsParser = null;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  tsLanguages = /* @__PURE__ */ new Map();
  treeSitterAvailable = false;
  modelAvailable = false;
  initialized = false;
  // ─── initialize ──────────────────────────────────────────────────────────
  /**
   * Load the embedding model + tree-sitter runtime.
   * Safe to call multiple times — subsequent calls are no-ops.
   * Reports 0→100 progress via onProgress.
   */
  async initialize(onProgress) {
    if (this.initialized) return;
    console.log(`${TAG} Initializing...`);
    onProgress?.(0);
    try {
      await this.openIdb();
      onProgress?.(8);
      this.appStructure = await this.loadAppStructure();
      onProgress?.(12);
      await this.loadEmbeddingModel(onProgress);
      onProgress?.(80);
      await this.initTreeSitter();
      onProgress?.(100);
      this.initialized = true;
      console.log(
        `${TAG} Ready — model=${this.modelAvailable} treeSitter=${this.treeSitterAvailable}`
      );
    } catch (err) {
      console.warn(`${TAG} Init error (partial init, keyword fallback active):`, err);
      this.initialized = true;
      onProgress?.(100);
    }
  }
  // ─── buildStructure ───────────────────────────────────────────────────────
  /**
   * Parse all code blocks in a set of messages with tree-sitter (or regex
   * fallback), extract functions/classes/imports/exports, and merge the result
   * into the persistent AppStructure.  Never overwrites — only adds.
   */
  async buildStructure(messages) {
    const blocks = this.extractCodeBlocks(messages);
    console.log(`${TAG} buildStructure — ${blocks.length} code block(s) found`);
    const current = this.appStructure ?? this.emptyStructure();
    for (const block of blocks) {
      if (!block.content.trim()) continue;
      const lang = block.language && block.language !== "unknown" ? block.language : this.detectLanguage(block.content);
      const parsed = await this.parseCode(block.content, lang);
      const path = block.path ?? `unknown.${langExt(lang)}`;
      const existing = current.files.find((f) => f.path === path);
      if (existing) {
        existing.functions = dedupe$1([...existing.functions, ...parsed.functions]);
        existing.classes = dedupe$1([...existing.classes, ...parsed.classes]);
        existing.imports = dedupe$1([...existing.imports, ...parsed.imports]);
        existing.exports = dedupe$1([...existing.exports, ...parsed.exports]);
        existing.dependencies = dedupe$1([...existing.dependencies, ...parsed.dependencies]);
      } else {
        current.files.push({ path, language: lang, ...parsed });
      }
    }
    current.modules = this.inferModules(current.files);
    current.lastUpdated = Date.now();
    this.appStructure = current;
    await this.saveAppStructure(current);
    return current;
  }
  // ─── indexSession ─────────────────────────────────────────────────────────
  /**
   * Generate and persist embeddings for every message + code block in a session.
   * Idempotent — skips sessions already indexed at the same message count.
   * Fire-and-forget safe: any error is logged and silently ignored.
   */
  async indexSession(session) {
    console.log(
      `${TAG} indexSession — session=${session.id} msgs=${session.messages.length}`
    );
    const db = await this.openIdb();
    const meta = await db.get(SESSIONS_META_STORE, session.id);
    if (meta?.messageCount === session.messages.length) {
      console.log(`${TAG} Session ${session.id} already indexed — skip`);
      return;
    }
    await this.buildStructure(session.messages);
    const rawChunks = this.sessionToChunks(session);
    const toIndex = rawChunks.slice(0, MAX_CHUNKS_PER_SESSION);
    console.log(`${TAG} Embedding ${toIndex.length} chunk(s) for session ${session.id}`);
    const embedded = await this.embedChunks(toIndex);
    const tx = db.transaction([CHUNKS_STORE, SESSIONS_META_STORE], "readwrite");
    for (const chunk of embedded) {
      await tx.objectStore(CHUNKS_STORE).put(chunk);
    }
    await tx.objectStore(SESSIONS_META_STORE).put({
      sessionId: session.id,
      messageCount: session.messages.length,
      indexedAt: Date.now()
    });
    await tx.done;
    console.log(`${TAG} Indexed ${embedded.length} chunk(s) for session ${session.id}`);
  }
  // ─── buildAttentionMap ────────────────────────────────────────────────────
  /**
   * Build a task-aware AttentionMap for a session.
   *
   * light  — keep chunks with score ≥ 0.4
   * strict — keep chunks with score ≥ 0.7
   * Always includes: last TAIL_SIZE messages + full structural context.
   */
  async buildAttentionMap(session, task, strength) {
    console.log(`${TAG} buildAttentionMap — strength=${strength}`);
    const threshold = THRESHOLDS[strength];
    await this.indexSession(session);
    const taskEmb = await this.getEmbedding(task);
    const db = await this.openIdb();
    const allChunks = await db.getAllFromIndex(CHUNKS_STORE, "sessionId", session.id);
    console.log(
      `${TAG} Scoring ${allChunks.length} chunk(s) against task embedding`
    );
    const scored = allChunks.map((chunk) => ({
      ...chunk,
      relevanceScore: taskEmb.some((v) => v !== 0) && chunk.embedding.length === EMBEDDING_DIM ? this.cosineSimilarity(taskEmb, chunk.embedding) : this.keywordScore(task, chunk.content)
    }));
    scored.sort((a, b) => b.relevanceScore - a.relevanceScore);
    const topChunks = scored.slice(0, SEARCH_TOP_K).filter((c) => c.relevanceScore >= threshold);
    const tail = session.messages.slice(-6).map((m) => {
      const existing = allChunks.find(
        (c) => c.type === "message" && c.content === m.content && c.role === m.role
      );
      return existing ?? this.messageToChunk(m, session.id, m.timestamp);
    });
    const merged = [...topChunks];
    for (const tailChunk of tail) {
      if (!merged.some((c) => c.id === tailChunk.id)) {
        merged.push({ ...tailChunk, relevanceScore: 1 });
      }
    }
    const codeChunks = merged.filter((c) => c.type === "code" && c.filePath);
    const highlightedFiles = dedupe$1(codeChunks.map((c) => c.filePath));
    const structure = this.appStructure ?? this.emptyStructure();
    const highlightedModules = structure.modules.filter((m) => m.relatedFiles.some((f) => highlightedFiles.includes(f))).map((m) => m.name);
    const focusedContext = this.buildFocusedContext(merged, structure);
    const originalSize = session.messages.reduce((s, m) => s + m.content.length, 0);
    const compressedSize = merged.reduce((s, c) => s + c.content.length, 0);
    const compressionRatio = originalSize > 0 ? Math.round((1 - compressedSize / originalSize) * 100) : 0;
    console.log(
      `${TAG} AttentionMap ready — chunks=${merged.length} files=${highlightedFiles.length} compression=${compressionRatio}%`
    );
    return {
      task,
      threshold,
      topChunks: merged,
      highlightedFiles,
      highlightedModules,
      structuralContext: structure,
      focusedContext,
      compressionRatio
    };
  }
  // ─── semanticSearch ───────────────────────────────────────────────────────
  /**
   * Search across ALL indexed sessions by semantic similarity to query.
   * Falls back to keyword scoring when the model is not loaded.
   */
  async semanticSearch(query, limit = 10) {
    console.log(`${TAG} semanticSearch — limit=${limit}`);
    const db = await this.openIdb();
    const allChunks = await db.getAll(CHUNKS_STORE);
    const queryEmb = await this.getEmbedding(query);
    const scored = allChunks.map((chunk) => ({
      ...chunk,
      relevanceScore: queryEmb.some((v) => v !== 0) && chunk.embedding.length === EMBEDDING_DIM ? this.cosineSimilarity(queryEmb, chunk.embedding) : this.keywordScore(query, chunk.content)
    }));
    scored.sort((a, b) => b.relevanceScore - a.relevanceScore);
    return scored.slice(0, limit);
  }
  // ─── clearIndex ───────────────────────────────────────────────────────────
  /**
   * Wipe all vector data and reset AppStructure.
   * Called from Settings → "Clear data".
   */
  async clearIndex() {
    const db = await this.openIdb();
    const tx = db.transaction(
      [CHUNKS_STORE, STRUCTURE_STORE, SESSIONS_META_STORE],
      "readwrite"
    );
    await Promise.all([
      tx.objectStore(CHUNKS_STORE).clear(),
      tx.objectStore(STRUCTURE_STORE).clear(),
      tx.objectStore(SESSIONS_META_STORE).clear()
    ]);
    await tx.done;
    this.appStructure = null;
    console.log(`${TAG} Index cleared`);
  }
  // ─── Private: IndexedDB setup ─────────────────────────────────────────────
  async openIdb() {
    if (this.idb) return this.idb;
    this.idb = await openDB(ATTENTION_DB_NAME, ATTENTION_DB_VERSION, {
      upgrade(db) {
        if (!db.objectStoreNames.contains(CHUNKS_STORE)) {
          const s = db.createObjectStore(CHUNKS_STORE, { keyPath: "id" });
          s.createIndex("sessionId", "sessionId");
          s.createIndex("type", "type");
          s.createIndex("timestamp", "timestamp");
        }
        if (!db.objectStoreNames.contains(STRUCTURE_STORE)) {
          db.createObjectStore(STRUCTURE_STORE, { keyPath: "key" });
        }
        if (!db.objectStoreNames.contains(SESSIONS_META_STORE)) {
          db.createObjectStore(SESSIONS_META_STORE, { keyPath: "sessionId" });
        }
      }
    });
    return this.idb;
  }
  // ─── Private: embedding model ─────────────────────────────────────────────
  async loadEmbeddingModel(onProgress) {
    try {
      const transformers = await __vitePreload(() => import('./transformers-DmVREIS2.js'),true?__vite__mapDeps([0,1,2]):void 0);
      const envObj = transformers.env;
      if (envObj?.backends?.onnx?.wasm) {
        envObj.backends.onnx.wasm.proxy = false;
        const hasSharedBuffer = typeof SharedArrayBuffer !== "undefined";
        const threads = hasSharedBuffer ? Math.min(4, navigator.hardwareConcurrency ?? 1) : 1;
        envObj.backends.onnx.wasm.numThreads = threads;
        console.log(`${TAG} ONNX WASM threads=${threads} SharedArrayBuffer=${hasSharedBuffer}`);
      }
      let device;
      if (typeof navigator !== "undefined" && navigator.gpu) {
        try {
          const adapter = await navigator.gpu.requestAdapter();
          if (adapter) {
            device = "webgpu";
            console.log(`${TAG} WebGPU adapter found — GPU inference enabled`);
          }
        } catch {
        }
      }
      const pipelineFn = transformers.pipeline ?? transformers.default;
      if (typeof pipelineFn !== "function") throw new Error("pipeline not found in @xenova/transformers");
      this.extractor = await pipelineFn(
        "feature-extraction",
        MODEL_ID,
        {
          ...device ? { device } : {},
          progress_callback: (info) => {
            if (info.status === "progress" && typeof info.progress === "number") {
              onProgress?.(Math.round(12 + info.progress * 0.66));
            }
          }
        }
      );
      this.modelAvailable = true;
      console.log(`${TAG} Embedding model loaded (${MODEL_ID}) device=${device ?? "wasm"}`);
    } catch (err) {
      console.warn(`${TAG} Model load failed — keyword fallback active:`, err);
      this.modelAvailable = false;
    }
  }
  // ─── Private: tree-sitter ─────────────────────────────────────────────────
  async initTreeSitter() {
    try {
      const mod = await __vitePreload(() => import('./web-tree-sitter-CwFUPQAP.js'),true?[]:void 0);
      const TS = mod.Parser ?? mod.default ?? mod;
      await TS.init({
        locateFile: (path) => {
          if (typeof chrome !== "undefined" && chrome.runtime?.getURL) {
            return chrome.runtime.getURL(`grammars/${path}`);
          }
          return `/grammars/${path}`;
        }
      });
      this.tsParser = new TS();
      this.treeSitterAvailable = true;
      console.log(`${TAG} web-tree-sitter runtime ready`);
    } catch (err) {
      console.warn(`${TAG} web-tree-sitter unavailable — regex fallback active:`, err);
      this.treeSitterAvailable = false;
    }
  }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  async loadLanguage(lang) {
    if (!this.treeSitterAvailable || !this.tsParser) return null;
    if (!GRAMMAR_FILE_MAP[lang]) return null;
    if (this.tsLanguages.has(lang)) return this.tsLanguages.get(lang);
    try {
      const mod = await __vitePreload(() => import('./web-tree-sitter-CwFUPQAP.js'),true?[]:void 0);
      const Lang = mod.Language ?? mod.default?.Language;
      const language = await Promise.race([
        Lang.load(grammarUrl(lang)),
        new Promise(
          (_, reject) => setTimeout(() => reject(new Error(`Grammar load timeout: ${lang}`)), 6e3)
        )
      ]);
      this.tsLanguages.set(lang, language);
      return language;
    } catch (err) {
      console.warn(`${TAG} Grammar load failed for "${lang}" — regex fallback`, err);
      return null;
    }
  }
  // ─── Private: code parsing ────────────────────────────────────────────────
  async parseCode(code, lang) {
    const language = await this.loadLanguage(lang);
    if (language && this.tsParser) {
      try {
        return this.parseWithTreeSitter(code, language);
      } catch (err) {
        console.warn(`${TAG} Tree-sitter parse error for "${lang}":`, err);
      }
    }
    return this.parseWithRegex(code, lang);
  }
  parseWithTreeSitter(code, language) {
    const functions = [];
    const classes = [];
    const imports = [];
    const exports$1 = [];
    const dependencies = [];
    this.tsParser.setLanguage(language);
    const tree = this.tsParser.parse(code);
    const walk = (node) => {
      switch (node.type) {
        case "function_declaration":
        case "function_definition": {
          const name = node.childForFieldName?.("name")?.text;
          if (name) functions.push(name);
          break;
        }
        case "method_definition":
        case "method": {
          const name = node.childForFieldName?.("name")?.text;
          if (name) functions.push(name);
          break;
        }
        case "lexical_declaration":
        case "variable_declaration": {
          for (const child of node.namedChildren ?? []) {
            if (child.type === "variable_declarator") {
              const val = child.childForFieldName?.("value");
              if (val?.type === "arrow_function" || val?.type === "function_expression") {
                const name = child.childForFieldName?.("name")?.text;
                if (name) functions.push(name);
              }
            }
          }
          break;
        }
        case "class_declaration":
        case "class_definition": {
          const name = node.childForFieldName?.("name")?.text;
          if (name) classes.push(name);
          break;
        }
        case "import_declaration":
        case "import_statement":
        case "import_from_statement": {
          const src = node.childForFieldName?.("source")?.text ?? node.childForFieldName?.("module_name")?.text;
          if (src) {
            const dep = src.replace(/['"]/g, "");
            imports.push(dep);
            if (!dep.startsWith(".")) dependencies.push(dep);
          }
          break;
        }
        case "export_statement":
        case "export_default_declaration": {
          const decl = node.childForFieldName?.("declaration");
          const name = decl?.childForFieldName?.("name")?.text ?? node.childForFieldName?.("name")?.text;
          if (name) exports$1.push(name);
          break;
        }
      }
      for (const child of node.namedChildren ?? []) {
        walk(child);
      }
    };
    walk(tree.rootNode);
    return {
      functions: dedupe$1(functions),
      classes: dedupe$1(classes),
      imports: dedupe$1(imports),
      exports: dedupe$1(exports$1),
      dependencies: dedupe$1(dependencies)
    };
  }
  parseWithRegex(code, lang) {
    const functions = [];
    const classes = [];
    const imports = [];
    const exports$1 = [];
    const dependencies = [];
    if (["typescript", "tsx", "javascript", "jsx", "js", "ts"].includes(lang)) {
      for (const m of code.matchAll(
        /(?:function\s+(\w+)|(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\()/gm
      )) {
        const name = m[1] ?? m[2];
        if (name) functions.push(name);
      }
      for (const m of code.matchAll(
        /(?:export\s+)?(?:const|let)\s+(\w+)\s*[:=][^=].*=>/gm
      )) {
        if (m[1]) functions.push(m[1]);
      }
      for (const m of code.matchAll(/class\s+(\w+)/gm)) {
        if (m[1]) classes.push(m[1]);
      }
      for (const m of code.matchAll(/import\s+.*?from\s+['"]([^'"]+)['"]/gm)) {
        if (m[1]) {
          imports.push(m[1]);
          if (!m[1].startsWith(".")) dependencies.push(m[1]);
        }
      }
      for (const m of code.matchAll(/import\s+['"]([^'"]+)['"]/gm)) {
        if (m[1] && !m[1].startsWith(".")) dependencies.push(m[1]);
      }
      for (const m of code.matchAll(
        /export\s+(?:default\s+)?(?:function|class|const|let)\s+(\w+)/gm
      )) {
        if (m[1]) exports$1.push(m[1]);
      }
    } else if (lang === "python") {
      for (const m of code.matchAll(/^def\s+(\w+)/gm)) if (m[1]) functions.push(m[1]);
      for (const m of code.matchAll(/^class\s+(\w+)/gm)) if (m[1]) classes.push(m[1]);
      for (const m of code.matchAll(/^(?:import\s+(\S+)|from\s+(\S+)\s+import)/gm)) {
        const dep = m[1] ?? m[2];
        if (dep) {
          imports.push(dep);
          dependencies.push(dep);
        }
      }
    } else if (lang === "rust") {
      for (const m of code.matchAll(/(?:pub\s+)?fn\s+(\w+)/gm)) if (m[1]) functions.push(m[1]);
      for (const m of code.matchAll(
        /(?:pub\s+)?(?:struct|enum)\s+(\w+)/gm
      )) if (m[1]) classes.push(m[1]);
      for (const m of code.matchAll(/use\s+([\w:]+)/gm)) if (m[1]) imports.push(m[1]);
    } else if (lang === "go") {
      for (const m of code.matchAll(/func\s+(?:\(\w+\s+\*?\w+\)\s+)?(\w+)/gm))
        if (m[1]) functions.push(m[1]);
      for (const m of code.matchAll(/type\s+(\w+)\s+struct/gm))
        if (m[1]) classes.push(m[1]);
      for (const m of code.matchAll(/"([\w./]+)"/gm))
        if (m[1]?.includes("/")) imports.push(m[1]);
    }
    return {
      functions: dedupe$1(functions).slice(0, 50),
      classes: dedupe$1(classes).slice(0, 20),
      imports: dedupe$1(imports).slice(0, 30),
      exports: dedupe$1(exports$1).slice(0, 20),
      dependencies: dedupe$1(dependencies).slice(0, 20)
    };
  }
  // ─── Private: code block extraction ──────────────────────────────────────
  extractCodeBlocks(messages) {
    const blocks = [];
    const codeRe = /```([\w-]*)[ \t]*\n([\s\S]*?)```/g;
    for (const msg of messages) {
      let match;
      codeRe.lastIndex = 0;
      while ((match = codeRe.exec(msg.content)) !== null) {
        const language = match[1].trim() || "unknown";
        const content = match[2];
        const firstLine = content.split("\n")[0]?.trim() ?? "";
        const pathMatch = firstLine.match(/^(?:\/\/|#|--)\s+([\w./\\-]+\.\w+)\s*$/) ?? firstLine.match(/^\/\*\*?\s*([\w./\\-]+\.\w+)\s*\*\//);
        const before = msg.content.slice(Math.max(0, match.index - 200), match.index);
        const ctx = before.split(/[.!?\n]/).filter((s) => s.trim().length > 10).pop()?.trim();
        blocks.push({ language, content, path: pathMatch?.[1], context: ctx });
      }
    }
    return blocks;
  }
  // ─── Private: language detection ─────────────────────────────────────────
  detectLanguage(code) {
    if (/import React|ReactDOM|jsx|tsx|<\w+\s*\/>/.test(code)) return "typescript";
    if (/def\s+\w+\(|from\s+\w+\s+import|print\(/.test(code)) return "python";
    if (/fn\s+\w+|let mut |impl\s+\w+|use std::/.test(code)) return "rust";
    if (/func\s+\w+|package\s+\w+|:=|fmt\./.test(code)) return "go";
    if (/class\s+\w+|function\s+\w+|const\s+\w+\s*=/.test(code)) return "javascript";
    return "unknown";
  }
  // ─── Private: cosine similarity ───────────────────────────────────────────
  cosineSimilarity(a, b) {
    if (a.length !== b.length || a.length === 0) return 0;
    let dot = 0, magA = 0, magB = 0;
    for (let i = 0; i < a.length; i++) {
      dot += a[i] * b[i];
      magA += a[i] * a[i];
      magB += b[i] * b[i];
    }
    const denom = Math.sqrt(magA) * Math.sqrt(magB);
    return denom === 0 ? 0 : dot / denom;
  }
  // ─── Private: keyword scoring (model fallback) ────────────────────────────
  keywordScore(query, content) {
    const tokens = query.toLowerCase().split(/\W+/).filter((w) => w.length > 2);
    if (tokens.length === 0) return 0;
    const lower = content.toLowerCase();
    const hits = tokens.filter((t) => lower.includes(t)).length;
    return hits / tokens.length;
  }
  // ─── Private: embedding generation ───────────────────────────────────────
  async getEmbedding(text) {
    if (!this.extractor || !this.modelAvailable) {
      return new Array(EMBEDDING_DIM).fill(0);
    }
    try {
      const out = await this.extractor(text, { pooling: "mean", normalize: true });
      return Array.from(out.data);
    } catch (err) {
      console.warn(`${TAG} Single embedding failed:`, err);
      return new Array(EMBEDDING_DIM).fill(0);
    }
  }
  async embedChunks(chunks) {
    if (!this.extractor || !this.modelAvailable) {
      return chunks.map((c) => ({ ...c, embedding: new Array(EMBEDDING_DIM).fill(0) }));
    }
    const result = [];
    for (let i = 0; i < chunks.length; i += BATCH_SIZE) {
      const batch = chunks.slice(i, i + BATCH_SIZE);
      try {
        const texts = batch.map((c) => c.content.slice(0, 512));
        const out = await this.extractor(texts, { pooling: "mean", normalize: true });
        for (let j = 0; j < batch.length; j++) {
          const start = j * EMBEDDING_DIM;
          const embedding = Array.from(out.data.slice(start, start + EMBEDDING_DIM));
          result.push({ ...batch[j], embedding });
        }
      } catch (err) {
        console.warn(`${TAG} Batch ${Math.floor(i / BATCH_SIZE)} embed failed:`, err);
        for (const c of batch) {
          result.push({ ...c, embedding: new Array(EMBEDDING_DIM).fill(0) });
        }
      }
    }
    return result;
  }
  // ─── Private: chunk generation ────────────────────────────────────────────
  sessionToChunks(session) {
    const chunks = [];
    for (const msg of session.messages) {
      chunks.push(this.messageToChunk(msg, session.id, msg.timestamp));
    }
    for (const block of this.extractCodeBlocks(session.messages)) {
      if (block.content.trim().length < 20) continue;
      chunks.push({
        id: `${session.id}-code-${chunks.length}`,
        sessionId: session.id,
        role: "assistant",
        content: block.content,
        embedding: [],
        relevanceScore: 0,
        type: "code",
        filePath: block.path,
        language: block.language && block.language !== "unknown" ? block.language : this.detectLanguage(block.content),
        timestamp: Date.now()
      });
    }
    return chunks;
  }
  messageToChunk(msg, sessionId, timestamp) {
    return {
      id: `${sessionId}-msg-${timestamp}-${msg.role}`,
      sessionId,
      role: msg.role,
      content: msg.content,
      embedding: [],
      relevanceScore: 0,
      type: "message",
      timestamp
    };
  }
  // ─── Private: AppStructure helpers ────────────────────────────────────────
  emptyStructure() {
    return { files: [], modules: [], lastUpdated: Date.now() };
  }
  inferModules(files) {
    const moduleMap = /* @__PURE__ */ new Map();
    for (const file of files) {
      const name = file.path.split("/").pop()?.replace(/\.\w+$/, "") ?? file.path;
      const type = inferModuleType(file.path, file.functions, file.classes);
      const existing = moduleMap.get(name);
      if (existing) {
        existing.relatedFiles = dedupe$1([...existing.relatedFiles, file.path]);
      } else {
        moduleMap.set(name, { name, type, relatedFiles: [file.path] });
      }
    }
    return Array.from(moduleMap.values());
  }
  async loadAppStructure() {
    try {
      const db = await this.openIdb();
      const row = await db.get(STRUCTURE_STORE, STRUCTURE_KEY);
      return row?.data ?? null;
    } catch {
      return null;
    }
  }
  async saveAppStructure(structure) {
    try {
      const db = await this.openIdb();
      await db.put(STRUCTURE_STORE, { key: STRUCTURE_KEY, data: structure });
    } catch (err) {
      console.warn(`${TAG} Failed to persist AppStructure:`, err);
    }
  }
  // ─── Private: focused context builder ────────────────────────────────────
  buildFocusedContext(chunks, structure) {
    const parts = [];
    if (structure.files.length > 0) {
      parts.push(
        `[Structural Map: ${structure.files.length} file(s), ${structure.modules.length} module(s)]`
      );
    }
    const highMsgs = chunks.filter((c) => c.type === "message" && c.relevanceScore >= 0.5).sort((a, b) => a.timestamp - b.timestamp).slice(0, 10);
    for (const m of highMsgs) {
      parts.push(`${m.role.toUpperCase()}: ${m.content.slice(0, 500)}`);
    }
    const highCode = chunks.filter((c) => c.type === "code" && c.relevanceScore >= 0.5).slice(0, 5);
    for (const c of highCode) {
      const label = c.filePath ? ` (${c.filePath})` : "";
      parts.push(`CODE${label}:
${c.content.slice(0, 1e3)}`);
    }
    return parts.join("\n\n");
  }
}
function dedupe$1(arr) {
  return [...new Set(arr)];
}
function langExt(lang) {
  const m = {
    typescript: "ts",
    tsx: "tsx",
    javascript: "js",
    python: "py",
    rust: "rs",
    go: "go"
  };
  return m[lang] ?? lang;
}
function inferModuleType(path, functions, classes) {
  const p = path.toLowerCase();
  if (/\.test\.|\.spec\.|__tests__/.test(p)) return "test";
  if (/config|settings|\.env/.test(p)) return "config";
  if (/components?\/|\.tsx$/.test(p) || classes.some((c) => /Props|Component/.test(c)))
    return "component";
  if (/service|api|client|fetch|http/.test(p)) return "service";
  if (/util|helper|lib\/|shared/.test(p)) return "util";
  if (functions.length > 0 && classes.length === 0) return "util";
  return "unknown";
}
const attentionEngine = new AttentionEngine();

function estimateTokens(text) {
  return Math.ceil(text.length / 4);
}
const MAX_VERBATIM_MESSAGES = 6;
const ERROR_STACKTRACE_RE = [
  /\b(?:Traceback|TypeError|ValueError|ReferenceError|SyntaxError|RuntimeError|AttributeError|NameError|ImportError|KeyError|IndexError|ZeroDivisionError)\b/,
  /\bat\s+\w[\w.]*\s+\([^)]+:\d+:\d+\)/,
  // JS/TS stack frames: at fn (file:line:col)
  /\bError:\s+\S/,
  // "Error: <message>" (any variant)
  /Exception\s+in\s+thread/
  // Java thread exceptions
];
function hasErrorOrStackTrace(content) {
  return ERROR_STACKTRACE_RE.some((re) => re.test(content));
}
function compressTier1Assistant(content, maxSentences) {
  if (hasErrorOrStackTrace(content)) return content;
  const SENTINEL = "__CF_CODE_";
  const blocks = [];
  const sanitized = content.replace(/```[\s\S]*?```/g, (match) => {
    const idx = blocks.length;
    blocks.push(match);
    return `${SENTINEL}${idx}__`;
  });
  const sentences = sanitized.split(/(?<=[.!?])\s+|\n{2,}/).map((s) => s.trim()).filter((s) => s.length > 0);
  const textSlice = sentences.slice(0, maxSentences).join(" ");
  const mentionedIndices = /* @__PURE__ */ new Set();
  for (const m of textSlice.matchAll(new RegExp(`${SENTINEL}(\\d+)__`, "g"))) {
    mentionedIndices.add(Number(m[1]));
  }
  let result = textSlice.replace(
    new RegExp(`${SENTINEL}(\\d+)__`, "g"),
    (_, idx) => blocks[Number(idx)]
  );
  const missed = blocks.filter((_, i) => !mentionedIndices.has(i)).join("\n\n");
  if (missed) result = `${result}

${missed}`;
  return result.trim() || content.slice(0, 200);
}
async function summarize(messages, options) {
  if (!messages.length) {
    const empty = {
      primaryGoal: "Not specified",
      currentFocus: "Not specified",
      completed: [],
      pending: [],
      decisions: "",
      facts: "",
      codeBlocks: [],
      conversationTail: [],
      messageCount: 0
    };
    return {
      mode: "verbatim",
      content: "(no conversation history)",
      extracted: empty,
      originalTokenEstimate: 0,
      summaryTokenEstimate: 0
    };
  }
  const compressed = options?.caveman ? aggressivelyCompressMessages(messages) : void 0;
  const extracted = extractContext(messages, compressed);
  const fullTranscript = messages.map((m) => `${m.role.toUpperCase()}: ${m.content}`).join("\n\n");
  const originalTokenEstimate = estimateTokens(fullTranscript);
  let content;
  let mode;
  const msgCount = messages.length;
  const originalLen = fullTranscript.length;
  if (msgCount < 30) {
    content = fullTranscript;
    mode = "verbatim";
  } else {
    mode = "summarized";
    const tailCount = msgCount <= 100 ? 10 : 6;
    const maxSentences = msgCount <= 100 ? 2 : 1;
    const tailStart = Math.max(3, messages.length - tailCount);
    const head = messages.slice(0, 3);
    const middle = messages.slice(3, tailStart);
    const tail = messages.slice(tailStart);
    const processedMiddle = middle.map((msg) => {
      if (msg.role === "user") return msg;
      return { ...msg, content: compressTier1Assistant(msg.content, maxSentences) };
    });
    const assembled = [...head, ...processedMiddle, ...tail];
    content = assembled.map((m) => `${m.role.toUpperCase()}: ${m.content}`).join("\n\n");
  }
  const summaryLen = content.length;
  const compressionPct = originalLen > 0 ? Math.round((1 - summaryLen / originalLen) * 100) : 0;
  console.log(
    `[ContextForge:tier1] ${msgCount} msgs → ${summaryLen} chars (${compressionPct}% compressed)`
  );
  return {
    mode,
    content,
    extracted,
    originalTokenEstimate,
    summaryTokenEstimate: estimateTokens(content)
  };
}
const FLUFF_PREFIX_RE = /^(?:(?:can|could|would|will|please|just|basically|actually|i was wondering|sure|of course|i'd like to|i need to|help me|hi|hello|hey)[,\s]+)+/i;
function stripUserFluff(text) {
  const clean = text.replace(FLUFF_PREFIX_RE, "").trim();
  const sentence = clean.split(/[.!?\n]/)[0].trim();
  return (sentence || clean).slice(0, 150);
}
function compressAssistant(text) {
  const noCode = text.replace(/```[\s\S]*?```/g, "").trim();
  const sentences = noCode.split(/(?<=[.!?])\s+/).map((s) => s.trim()).filter((s) => s.length > 20);
  const decisions = sentences.filter(
    (s) => DECISION_RE.some((re) => re.test(s))
  );
  const chosen = decisions.slice(0, 2);
  if (chosen.length === 0 && sentences.length > 0) chosen.push(sentences[0]);
  return chosen.join(" ");
}
function aggressivelyCompressMessages(messages) {
  if (messages.length <= MAX_VERBATIM_MESSAGES) return messages;
  const tail = messages.slice(-MAX_VERBATIM_MESSAGES);
  const body = messages.slice(0, -MAX_VERBATIM_MESSAGES);
  const compressedBody = body.map((msg) => ({
    ...msg,
    content: msg.role === "user" ? stripUserFluff(msg.content) : compressAssistant(msg.content)
  }));
  return [...compressedBody, ...tail];
}
function extractContext(messages, compressed) {
  const src = compressed ?? messages;
  return {
    primaryGoal: extractPrimaryGoal(messages),
    currentFocus: extractCurrentFocus(messages),
    completed: extractCompleted(src),
    pending: extractPending(src),
    decisions: extractDecisions(src),
    facts: extractFacts(src),
    codeBlocks: extractAllCodeBlocks(messages),
    conversationTail: messages.slice(-MAX_VERBATIM_MESSAGES),
    messageCount: messages.length
  };
}
function extractPrimaryGoal(messages) {
  const userMessages = messages.filter((m) => m.role === "user");
  if (!userMessages.length) return "Not specified";
  const first = userMessages[0].content.trim();
  return first.length > 600 ? first.slice(0, 600) + "…" : first;
}
function extractCurrentFocus(messages) {
  const userMessages = messages.filter((m) => m.role === "user");
  const lastThree = userMessages.slice(-3);
  if (!lastThree.length) return "Not specified";
  return lastThree.map((m) => {
    const text = m.content.trim();
    return text.length > 250 ? text.slice(0, 250) + "…" : text;
  }).join(" → ");
}
const COMPLETED_RE = [
  /^(?:here(?:'s| is)|i(?:'ve| have)|done|created|updated|fixed|added|implemented|built)[:\s]/im,
  /(?:\bis now\b|\bworks now\b|\bsuccessfully\b|\bcompleted?\b)/im
];
function extractCompleted(messages) {
  const items = [];
  for (const msg of messages) {
    if (msg.role !== "assistant") continue;
    if (!COMPLETED_RE.some((re) => re.test(msg.content))) continue;
    const firstLine = msg.content.split("\n")[0].trim();
    const sentence = firstLine.split(/[.!?]/)[0].trim();
    if (sentence.length > 10 && sentence.length < 200) {
      items.push(sentence);
    }
  }
  return dedupe(items).slice(0, 12);
}
const PENDING_RE = [
  /\btodo\b|next step|you(?:'ll| will) need|remaining|left to do|still need/im,
  /\bone more thing\b|should also|we need to|i(?:'ll| will) need/im,
  /\bnot yet\b|\bpending\b/im
];
function extractPending(messages) {
  const items = [];
  for (const msg of messages.slice(-20)) {
    if (!PENDING_RE.some((re) => re.test(msg.content))) continue;
    const sentences = msg.content.split(/[.!?\n]/).filter((s) => s.trim().length > 15);
    for (const sentence of sentences) {
      if (PENDING_RE.some((re) => re.test(sentence))) {
        items.push(sentence.trim());
      }
    }
  }
  return dedupe(items).slice(0, 10);
}
const DECISION_RE = [
  /instead of|rather than|chose|chosen|decided|opted for|went with/im,
  /the reason|because.*approach|trade-?off/im,
  /(?:will|'ll) use .{3,30} (?:instead|for this|here)/im
];
function extractDecisions(messages) {
  const items = [];
  for (const msg of messages) {
    if (msg.role !== "assistant") continue;
    const sentences = msg.content.split(/[.!?\n]/).filter((s) => s.trim().length > 20);
    for (const s of sentences) {
      if (DECISION_RE.some((re) => re.test(s))) {
        items.push(`- ${s.trim()}`);
      }
    }
  }
  return dedupe(items).slice(0, 8).join("\n");
}
const FACT_RE = [
  /\b(?:must|cannot|can't|requires|depends on|note that|important:|warning:)\b/im,
  /\b(?:version|api key|endpoint|port|url|config)\b/im
];
function extractFacts(messages) {
  const items = [];
  const earlyMessages = messages.slice(0, Math.min(20, messages.length));
  for (const msg of earlyMessages) {
    const sentences = msg.content.split(/[.!?\n]/).filter((s) => s.trim().length > 20);
    for (const s of sentences) {
      if (FACT_RE.some((re) => re.test(s))) {
        items.push(`- ${s.trim()}`);
      }
    }
  }
  return dedupe(items).slice(0, 8).join("\n");
}
function extractAllCodeBlocks(messages) {
  const blocks = [];
  const codeRe = /```([\w-]*)[ \t]*\n([\s\S]*?)```/g;
  for (const msg of messages) {
    let match;
    codeRe.lastIndex = 0;
    while ((match = codeRe.exec(msg.content)) !== null) {
      const language = match[1].trim();
      const content = match[2];
      const firstLine = content.split("\n")[0]?.trim() ?? "";
      const pathMatch = firstLine.match(/^(?:\/\/|#|--)\s+([\w./\\-]+\.\w+)\s*$/) ?? firstLine.match(/^\/\*\*?\s*([\w./\\-]+\.\w+)\s*\*\//);
      const path = pathMatch?.[1];
      const before = msg.content.slice(
        Math.max(0, match.index - 200),
        match.index
      );
      const contextSentences = before.split(/[.!?\n]/).filter((s) => s.trim().length > 10);
      const context = contextSentences[contextSentences.length - 1]?.trim();
      blocks.push({ language, content, path, context });
    }
  }
  return blocks;
}
function buildPlainTextSummary(ex) {
  const parts = [
    `=== CONVERSATION SUMMARY (${ex.messageCount} messages) ===`,
    `
GOAL:
${ex.primaryGoal}`,
    `
CURRENT FOCUS:
${ex.currentFocus}`
  ];
  if (ex.completed.length) {
    parts.push(`
COMPLETED:
${ex.completed.map((c) => `- ${c}`).join("\n")}`);
  }
  if (ex.pending.length) {
    parts.push(`
PENDING:
${ex.pending.map((p) => `- ${p}`).join("\n")}`);
  }
  if (ex.decisions) {
    parts.push(`
KEY DECISIONS:
${ex.decisions}`);
  }
  if (ex.codeBlocks.length) {
    parts.push(`
CODE (${ex.codeBlocks.length} block(s)):`);
    for (const block of ex.codeBlocks) {
      const header = block.path ? ` ${block.path}` : block.context ? ` (${block.context})` : "";
      parts.push(`\`\`\`${block.language}${header}
${block.content}\`\`\``);
    }
  }
  parts.push(
    `
=== RECENT MESSAGES (verbatim) ===`,
    ex.conversationTail.map((m) => `${m.role.toUpperCase()}: ${m.content}`).join("\n\n")
  );
  return parts.join("\n");
}
function dedupe(arr) {
  return [...new Set(arr)];
}
const TIER2_DECISION_RE = [
  /\bi['\u2019]ll use\b/i,
  /\bbest approach\b/i,
  /\bwe decided\b/i,
  /\bthe fix is\b/i,
  /\buse\s+\S+\s+for\b/i,
  /\bthis works because\b/i
];
const TIER2_BUG_RE = [
  /\bthe issue was\b/i,
  /\bbug was caused\b/i,
  /\bfixed by\b/i,
  /\berror occurs because\b/i,
  /\broot cause\b/i
];
function summarizeIntelligent(messages) {
  const t0 = Date.now();
  const userMessages = messages.filter((m) => m.role === "user");
  const goal = userMessages.length > 0 ? userMessages[0].content.trim().slice(0, 600) || "Not specified" : "Not specified";
  const lastUserMessages = userMessages.slice(-6);
  const currentState = lastUserMessages.length > 0 ? lastUserMessages.map((m) => {
    const t = m.content.trim();
    return t.length > 250 ? t.slice(0, 250) + "…" : t;
  }).join(" → ") : "Not specified";
  const rawDecisions = [];
  for (const msg of messages) {
    if (msg.role !== "assistant") continue;
    const sentences = msg.content.split(/(?<=[.!?])\s+|\n+/).map((s) => s.trim()).filter((s) => s.length > 20);
    for (const s of sentences) {
      if (TIER2_DECISION_RE.some((re) => re.test(s))) rawDecisions.push(s);
    }
  }
  const decisions = dedupe(rawDecisions).slice(0, 20);
  const rawBugs = [];
  for (const msg of messages) {
    const sentences = msg.content.split(/(?<=[.!?])\s+|\n+/).map((s) => s.trim()).filter((s) => s.length > 20);
    for (const s of sentences) {
      if (TIER2_BUG_RE.some((re) => re.test(s))) rawBugs.push(s);
    }
  }
  const bugsFixed = dedupe(rawBugs).slice(0, 15);
  const codeBlocks = [];
  const codeRe = /```([\w-]*)[ \t]*\n([\s\S]*?)```/g;
  for (const msg of messages) {
    let match;
    codeRe.lastIndex = 0;
    while ((match = codeRe.exec(msg.content)) !== null) {
      const language = match[1].trim() || "text";
      const code = match[2];
      const firstLine = code.split("\n")[0]?.trim() ?? "";
      const pathMatch = firstLine.match(/^(?:\/\/|#|--) ([\w./\\-]+\.\w+)\s*$/) ?? firstLine.match(/^\/\*\*?\s*([\w./\\-]+\.\w+)\s*\*\//);
      codeBlocks.push({ language, path: pathMatch?.[1], code });
    }
  }
  const tail = messages.slice(-8);
  const originalSize = messages.reduce((s, m) => s + m.content.length, 0);
  const extractedSize = goal.length + currentState.length + decisions.reduce((s, d) => s + d.length, 0) + bugsFixed.reduce((s, b) => s + b.length, 0) + codeBlocks.reduce((s, c) => s + c.code.length, 0) + tail.reduce((s, m) => s + m.content.length, 0);
  const compressionRatio = originalSize > 0 ? Math.round((1 - extractedSize / originalSize) * 100) : 0;
  console.log(
    `[ContextForge:tier2] ${messages.length} msgs → extracted:
  goals=1 decisions=${decisions.length} bugs=${bugsFixed.length} code_blocks=${codeBlocks.length} → ${extractedSize} chars (${compressionRatio}% compressed) [${Date.now() - t0}ms]`
  );
  return {
    goal,
    currentState,
    decisions,
    bugsFixed,
    codeBlocks,
    tail,
    originalCount: messages.length,
    compressionRatio
  };
}
async function summarizeWithAttention(messages, task, strength, session) {
  try {
    if (!attentionEngine.initialized) {
      await attentionEngine.initialize();
    }
    await attentionEngine.indexSession(session);
    const attentionMap = await attentionEngine.buildAttentionMap(session, task, strength);
    const threshold = attentionMap.threshold;
    const scoreByContent = /* @__PURE__ */ new Map();
    for (const chunk of attentionMap.topChunks) {
      if (chunk.type === "message") {
        const prev = scoreByContent.get(chunk.content) ?? 0;
        if (chunk.relevanceScore > prev) scoreByContent.set(chunk.content, chunk.relevanceScore);
      }
    }
    const highScoreCode = new Set(
      attentionMap.topChunks.filter((c) => c.type === "code" && c.relevanceScore >= threshold).map((c) => c.content.trim())
    );
    const tailStart = Math.max(0, messages.length - MAX_VERBATIM_MESSAGES);
    const processed = messages.map((msg, idx) => {
      if (idx >= tailStart) return msg;
      const score = scoreByContent.get(msg.content) ?? 0;
      if (score >= threshold) {
        return { ...msg, content: stripLowScoreCode(msg.content, highScoreCode) };
      }
      const noCode = msg.content.replace(/```[\s\S]*?```/g, "").trim();
      const first = noCode.split(/[.!?\n]/)[0]?.trim() ?? noCode;
      return { ...msg, content: first.slice(0, 200) };
    });
    const extracted = extractContext(processed);
    const summary = buildPlainTextSummary(extracted);
    const originalSize = messages.reduce((s, m) => s + m.content.length, 0);
    const compressedSize = processed.reduce((s, m) => s + m.content.length, 0);
    const compressionRatio = originalSize > 0 ? Math.round((1 - compressedSize / originalSize) * 100) : 0;
    console.log(
      `[ContextForge:summarizer] summarizeWithAttention: msgs=${messages.length}→${processed.length} compression=${compressionRatio}%`
    );
    return { summary, attentionMap, compressionRatio };
  } catch (err) {
    console.warn(
      "[ContextForge:summarizer] summarizeWithAttention failed — falling back to summarize():",
      err
    );
    const fallback = await summarize(messages);
    return {
      summary: fallback.content,
      attentionMap: {
        task,
        threshold: 0.4,
        topChunks: [],
        highlightedFiles: [],
        highlightedModules: [],
        structuralContext: { files: [], modules: [], lastUpdated: Date.now() },
        focusedContext: "",
        compressionRatio: 0
      },
      compressionRatio: 0
    };
  }
}
function stripLowScoreCode(content, highScoreCode) {
  return content.replace(/```[\s\S]*?```/g, (match) => {
    const inner = match.replace(/^```[\w-]*[ \t]*\n?/, "").replace(/\n?```$/, "").trim();
    return highScoreCode.has(inner) ? match : "";
  });
}

export { __vitePreload as _, summarizeIntelligent as a, summarize as b, attentionEngine as c, openDB as o, summarizeWithAttention as s };
