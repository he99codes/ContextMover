import { s as startSessionCapture, w as waitForAnyElement, a as setPromptInputValue, e as extractMessageContent } from '../../shared-kgClQg5h.js';
import '../../session-id-BlkLb76o.js';

console.log("[ContextForge] Grok content script loaded");
function scrapeMessages() {
  const collected = [];
  const hasAsst = () => collected.some((e) => e.role === "assistant");
  const hasUser = () => collected.some((e) => e.role === "user");
  {
    const sel = '[class*="UserMessage"], [class*="AssistantMessage"]';
    const els = [...document.querySelectorAll(sel)].filter((el) => !el.parentElement?.closest(sel));
    for (const el of els) {
      const role = el.className.includes("User") ? "user" : "assistant";
      collected.push({ el, role });
    }
    console.log(`[ContextForge:grok] A legacy-class: ${els.length}`);
  }
  if (!hasAsst()) {
    const els = [...document.querySelectorAll("[data-message-author-role]")].filter((el) => !el.parentElement?.closest("[data-message-author-role]"));
    for (const el of els) {
      const role = el.dataset.messageAuthorRole;
      if (role === "user" || role === "assistant") collected.push({ el, role });
    }
    console.log(`[ContextForge:grok] B data-author: ${els.length}`);
  }
  if (!hasAsst()) {
    const userSel = '[class*="user-message"], [class*="user-query"], [class*="user-bubble"], [class*="query-bubble"]';
    const asstSel = '[class*="bot-message"], [class*="assistant-message"], [class*="response-bubble"], [class*="model-response"], [class*="message-bubble"][class*="assistant"]';
    const userEls = [...document.querySelectorAll(userSel)].filter((el) => !el.parentElement?.closest(userSel));
    const asstEls = [...document.querySelectorAll(asstSel)].filter((el) => !el.parentElement?.closest(asstSel));
    for (const el of userEls) collected.push({ el, role: "user" });
    for (const el of asstEls) collected.push({ el, role: "assistant" });
    console.log(`[ContextForge:grok] C class-substr: user=${userEls.length} asst=${asstEls.length}`);
  }
  if (!hasAsst() && !hasUser()) {
    const candidates = [...document.querySelectorAll(
      '[class*="message"], [class*="bubble"], [class*="turn"], [class*="chat-item"]'
    )].filter((el) => {
      return !el.parentElement?.closest('[class*="message"], [class*="bubble"], [class*="turn"], [class*="chat-item"]');
    });
    candidates.forEach((el, i) => {
      collected.push({ el, role: i % 2 === 0 ? "user" : "assistant" });
    });
    console.log(`[ContextForge:grok] D generic-bubble: ${candidates.length} (alternating roles)`);
  }
  if (collected.length === 0) {
    const main = document.querySelector("main") ?? document.body;
    const classHits = /* @__PURE__ */ new Map();
    const testidHits = /* @__PURE__ */ new Set();
    main.querySelectorAll("*").forEach((el) => {
      if (el.dataset.testid) testidHits.add(el.dataset.testid);
      el.classList.forEach((c) => {
        if (/message|bubble|turn|chat|query|response|prompt|author|user|bot|assistant/i.test(c)) {
          classHits.set(c, (classHits.get(c) ?? 0) + 1);
        }
      });
    });
    const topClasses = [...classHits.entries()].sort((a, b) => b[1] - a[1]).slice(0, 30);
    console.warn(`[ContextForge:grok] NO messages found. DOM diagnostic:`);
    console.warn(`[ContextForge:grok]   candidate classes (name × count):`, topClasses);
    console.warn(`[ContextForge:grok]   testids on page:`, [...testidHits].sort().join(", "));
    return [];
  }
  collected.sort((a, b) => {
    const pos = a.el.compareDocumentPosition(b.el);
    return pos & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
  });
  const messages = [];
  for (const { el, role } of collected) {
    const content = extractMessageContent(el);
    if (content) messages.push({ role, content, timestamp: Date.now() });
    else console.warn(`[ContextForge:grok] empty content for role=${role}`);
  }
  const userCount = messages.filter((m) => m.role === "user").length;
  const asstCount = messages.filter((m) => m.role === "assistant").length;
  console.log(`[ContextForge:grok] FINAL: ${messages.length} msgs (user=${userCount} asst=${asstCount})`);
  console.log(`[ContextForge:grok] preview:`, messages.map((m) => ({ role: m.role, preview: m.content.slice(0, 60) })));
  if (asstCount === 0 && userCount > 0) {
    console.error(`[ContextForge:grok] ASSISTANT MESSAGES MISSING`);
  }
  return messages;
}
startSessionCapture({
  platform: "grok",
  selectorOrElement: "main",
  scrapeMessages
});
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "INJECT_CONTEXT" && msg.platform === "grok") {
    void injectIntoGrokInput(msg.prompt).then(sendResponse);
    return true;
  }
});
const GROK_INJECT_SELECTORS = [
  // Current Grok composer (confirmed 2026-04) — [data-testid="chat-input"]
  // is a WRAPPER div; the real editor is a nested contenteditable ProseMirror.
  // We MUST target the inner contenteditable, not the wrapper.
  '[data-testid="chat-input"] [contenteditable="true"]',
  '[data-testid="chat-input"] .ProseMirror',
  '[data-testid="composer-text-input"] [contenteditable="true"]',
  '[data-testid="composer-text-input"]',
  // legacy
  'textarea[placeholder*="Ask"]',
  // Grok "Ask anything" placeholder
  'textarea[placeholder*="message"]',
  '[contenteditable="true"][role="textbox"]',
  '.ProseMirror[contenteditable="true"]',
  // TipTap / ProseMirror editor
  '[class*="composer"] textarea',
  '[class*="input"] textarea',
  "form textarea",
  "textarea:not([readonly])",
  // broad textarea fallback
  '[contenteditable="true"]'
  // last-resort contenteditable
];
async function injectIntoGrokInput(text) {
  let input = null;
  let matchedSelector = "";
  for (const sel of GROK_INJECT_SELECTORS) {
    const el = document.querySelector(sel);
    if (el) {
      input = el;
      matchedSelector = sel;
      break;
    }
  }
  if (!input) {
    input = await waitForAnyElement(GROK_INJECT_SELECTORS);
    matchedSelector = input ? GROK_INJECT_SELECTORS.find((s) => document.querySelector(s) === input) ?? "(late)" : "";
  }
  if (!input) {
    console.warn("[ContextForge:grok] injection failed — no composer element matched any selector");
    return {
      ok: false,
      error: "Grok input box not found. Make sure a Grok chat tab is open and the page has finished loading."
    };
  }
  console.log(`[ContextForge:grok] injecting via selector: ${matchedSelector}, tag=${input.tagName}, contentEditable=${input.isContentEditable}`);
  if (!setPromptInputValue(input, text)) {
    return {
      ok: false,
      error: `Grok input (${input.tagName.toLowerCase()}) did not accept the text. Try reloading the tab.`
    };
  }
  console.log("[ContextForge:grok] injection succeeded");
  return { ok: true };
}
