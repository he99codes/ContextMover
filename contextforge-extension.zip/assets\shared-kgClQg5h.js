import { r as resolveSessionId, m as makeLegacyChecker } from './session-id-BlkLb76o.js';

const legacyChecker = makeLegacyChecker();
function createObserver(selectorOrElement, callback, debounceMs = 300) {
  let debounceTimer = null;
  const debouncedCallback = () => {
    if (debounceTimer !== null) clearTimeout(debounceTimer);
    debounceTimer = setTimeout(callback, debounceMs);
  };
  const observer = new MutationObserver(debouncedCallback);
  function attach() {
    const target = typeof selectorOrElement === "string" ? document.querySelector(selectorOrElement) ?? document.body : selectorOrElement;
    if (!target) {
      document.addEventListener("DOMContentLoaded", attach, { once: true });
      return;
    }
    observer.observe(target, {
      childList: true,
      subtree: true,
      characterData: true
    });
  }
  attach();
  return observer;
}
function defaultSessionTitle(messages) {
  const source = messages.find((message) => message.role === "user")?.content ?? messages[0]?.content ?? "Untitled session";
  return truncate(source.replace(/\s+/g, " ").trim(), 72);
}
function startSessionCapture(config) {
  const flag = `__contextForge_${config.platform}_loaded`;
  const w = window;
  if (w[flag]) {
    console.log(`[ContextForge] ${config.platform} content script already active — skipping duplicate init`);
    return;
  }
  w[flag] = true;
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.type === "PING") {
      sendResponse({ ok: true, platform: config.platform });
      return;
    }
  });
  let sessionId = null;
  let lastSnapshotKey = "";
  let lastHref = window.location.href;
  let lastUnchangedAt = 0;
  const UNCHANGED_COOLDOWN_MS = 5e3;
  async function ensureSessionId() {
    if (sessionId) return sessionId;
    sessionId = await resolveSessionId(
      config.platform,
      window.location.href,
      legacyChecker
    );
    console.log(`[ContextForge] ${config.platform}: resolved sessionId=${sessionId}`);
    return sessionId;
  }
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type !== "SESSION_FORGOTTEN") return;
    if (msg.sessionId && sessionId && msg.sessionId === sessionId) {
      console.log(
        `[ContextForge] ${config.platform}: received SESSION_FORGOTTEN for ${sessionId} — clearing cache, next capture will mint new id`
      );
      sessionId = null;
      lastSnapshotKey = "";
    }
  });
  const FETCH_FALLBACK_WINDOW_MS = 6e4;
  const capture = async () => {
    const currentHref = window.location.href;
    if (currentHref !== lastHref) {
      lastHref = currentHref;
      sessionId = null;
      lastSnapshotKey = "";
      console.log(`[ContextForge] URL changed — re-resolving sessionId`);
    }
    const fc = window.__contextForgeFetchCaptured;
    if (fc && Date.now() - fc.at < FETCH_FALLBACK_WINDOW_MS) {
      console.log(
        `[ContextForge] ${config.platform}: fetch-intercept active (count=${fc.count}, age=${Date.now() - fc.at}ms), skipping DOM scrape`
      );
      return;
    }
    if (lastUnchangedAt > 0 && Date.now() - lastUnchangedAt < UNCHANGED_COOLDOWN_MS) {
      return;
    }
    console.log(`[ContextForge] Capture triggered for ${config.platform} (DOM fallback)`);
    const messages = config.scrapeMessages();
    if (!messages.length) {
      console.log(`[ContextForge] No messages found, skipping capture`);
      return;
    }
    const assistantCount = messages.filter((m) => m.role === "assistant").length;
    if (assistantCount === 0) {
      console.log(
        `[ContextForge] Skipping capture — ${messages.length} user-only messages (awaiting assistant response)`
      );
      return;
    }
    const title = config.getTitle?.(messages) ?? defaultSessionTitle(messages);
    const lastMessage = messages[messages.length - 1];
    const snapshotKey = `${messages.length}:${lastMessage?.role ?? ""}:${lastMessage?.content ?? ""}`;
    if (snapshotKey === lastSnapshotKey) {
      lastUnchangedAt = Date.now();
      console.log(`[ContextForge] Snapshot unchanged, skipping`);
      return;
    }
    lastUnchangedAt = 0;
    lastSnapshotKey = snapshotKey;
    const resolvedId = await ensureSessionId();
    console.log(`[ContextForge] Sending CAPTURE_SESSION for session: ${resolvedId}`);
    chrome.runtime.sendMessage({
      type: "CAPTURE_SESSION",
      payload: {
        platform: config.platform,
        sessionId: resolvedId,
        title,
        messages
      }
    });
  };
  createObserver(config.selectorOrElement, capture);
  setTimeout(capture, 1e3);
  window.addEventListener("load", capture, { once: true });
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") {
      capture();
    }
  });
  window.addEventListener("popstate", () => setTimeout(capture, 500));
}
const CF_CHROME_SELECTORS = [
  "button",
  "svg",
  '[role="button"]',
  '[role="toolbar"]',
  // NOTE: [role="group"] intentionally omitted — Claude wraps response content
  // in role="group" divs; removing it strips the entire assistant message body.
  "[data-testid*=copy]",
  "[data-testid*=action]",
  "[data-testid*=retry]",
  "[data-testid*=thumbs]",
  "[data-testid*=feedback]",
  "[class*=tooltip]"
].join(", ");
const BLOCK_TAGS = /* @__PURE__ */ new Set([
  "p",
  "div",
  "section",
  "article",
  "header",
  "footer",
  "li",
  "ul",
  "ol",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "blockquote",
  "tr",
  "pre",
  "hr",
  "br"
]);
function getTextContent(node) {
  if (node.nodeType === Node.TEXT_NODE) return node.textContent ?? "";
  if (node.nodeType !== Node.ELEMENT_NODE) return "";
  const el = node;
  const tag = el.tagName.toLowerCase();
  if (tag === "script" || tag === "style") return "";
  if (tag === "br") return "\n";
  const children = Array.from(el.childNodes).map(getTextContent).join("");
  return BLOCK_TAGS.has(tag) ? `
${children}
` : children;
}
function extractMessageContent(el) {
  const clone = el.cloneNode(true);
  clone.querySelectorAll("pre").forEach((pre) => {
    const codeEl = pre.querySelector("code");
    const lang = (codeEl?.className ?? "").match(/language-([\w-]+)/)?.[1] ?? "";
    const code = (codeEl ?? pre).textContent?.trim() ?? "";
    const textNode = document.createTextNode(`
\`\`\`${lang}
${code}
\`\`\`
`);
    pre.replaceWith(textNode);
  });
  clone.querySelectorAll(CF_CHROME_SELECTORS).forEach((n) => n.remove());
  return getTextContent(clone).replace(/\n{3,}/g, "\n\n").trim();
}
function truncate(text, maxChars) {
  return text.length > maxChars ? `${text.slice(0, maxChars - 1)}…` : text;
}
async function waitForAnyElement(selectors, timeoutMs = 4e3) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (el) return el;
    }
    await new Promise((resolve) => window.setTimeout(resolve, 100));
  }
  return null;
}
function setPromptInputValue(input, text) {
  input.focus();
  if (input instanceof HTMLTextAreaElement) {
    const nativeSetter = Object.getOwnPropertyDescriptor(
      window.HTMLTextAreaElement.prototype,
      "value"
    )?.set;
    nativeSetter?.call(input, text);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    return input.value === text;
  }
  if (input.isContentEditable) {
    document.execCommand("selectAll", false, void 0);
    const inserted = document.execCommand("insertText", false, text);
    if (inserted && (input.textContent?.trim().length ?? 0) > 0) {
      return true;
    }
    try {
      input.innerText = text;
      input.dispatchEvent(
        new InputEvent("input", { bubbles: true, data: text, inputType: "insertText" })
      );
      if ((input.textContent?.trim().length ?? 0) > 0) return true;
    } catch {
    }
    input.textContent = text;
    input.dispatchEvent(new InputEvent("input", { bubbles: true, data: text }));
    return (input.textContent?.trim().length ?? 0) > 0;
  }
  return false;
}

export { setPromptInputValue as a, extractMessageContent as e, startSessionCapture as s, waitForAnyElement as w };
