import { r as resolveSessionId, m as makeLegacyChecker } from './session-id-BlkLb76o.js';

const TAG = "[ContextForge:bridge]";
const VALID_PLATFORMS = ["claude", "chatgpt", "gemini", "grok", "perplexity", "deepseek"];
const legacyChecker = makeLegacyChecker();
const w = window;
if (w.__contextForgeBridgeInstalled) {
  console.log(`${TAG} already installed, skipping`);
} else {
  w.__contextForgeBridgeInstalled = true;
  install();
}
function install() {
  const accumulator = /* @__PURE__ */ new Map();
  const sessionCache = /* @__PURE__ */ new Map();
  async function ensureSessionId(platform) {
    const href = window.location.href;
    const cached = sessionCache.get(platform);
    if (cached && cached.href === href) return cached.id;
    const id = await resolveSessionId(platform, href, legacyChecker);
    sessionCache.set(platform, { href, id });
    return id;
  }
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type !== "SESSION_FORGOTTEN") return;
    const forgottenId = msg.sessionId;
    if (!forgottenId) return;
    accumulator.delete(forgottenId);
    for (const [p, entry] of sessionCache) {
      if (entry.id === forgottenId) sessionCache.delete(p);
    }
    w.__contextForgeFetchCaptured = void 0;
    console.log(`${TAG} cleared cached state for forgotten session ${forgottenId}`);
  });
  window.addEventListener("contextforge:captured", (rawEvent) => {
    void (async () => {
      try {
        const event = rawEvent;
        const detail = event.detail;
        if (!detail || typeof detail !== "object") return;
        const { platform, messages } = detail;
        if (!VALID_PLATFORMS.includes(platform)) {
          console.warn(`${TAG} invalid platform: ${platform}`);
          return;
        }
        if (!Array.isArray(messages) || messages.length === 0) {
          return;
        }
        const cleaned = [];
        for (const m of messages) {
          if (!m || typeof m !== "object") continue;
          if (m.role !== "user" && m.role !== "assistant") continue;
          if (typeof m.content !== "string" || m.content.trim().length === 0) continue;
          cleaned.push({
            role: m.role,
            content: m.content,
            timestamp: typeof m.timestamp === "number" ? m.timestamp : Date.now(),
            ...Array.isArray(m.codeBlocks) && m.codeBlocks.length > 0 ? { codeBlocks: m.codeBlocks } : {}
          });
        }
        if (cleaned.length === 0) return;
        const sessionId = await ensureSessionId(platform);
        const prior = accumulator.get(sessionId) ?? [];
        const merged = mergeMessages(prior, cleaned);
        accumulator.set(sessionId, merged);
        const userCount = merged.filter((m) => m.role === "user").length;
        const assistantCount = merged.filter((m) => m.role === "assistant").length;
        if (assistantCount === 0) {
          console.log(
            `${TAG} ${platform}: ${userCount} user, 0 assistant — waiting for assistant turn`
          );
          return;
        }
        w.__contextForgeFetchCaptured = { at: Date.now(), count: merged.length };
        const title = deriveTitle(platform, merged);
        console.log(
          `${TAG} ${platform}: forwarding ${merged.length} msg(s) (user=${userCount} asst=${assistantCount}) → service worker`
        );
        try {
          chrome.runtime.sendMessage(
            {
              type: "CAPTURE_SESSION",
              payload: {
                platform,
                sessionId,
                title,
                messages: merged,
                source: "fetch-intercept"
              }
            },
            () => {
              void chrome.runtime.lastError;
            }
          );
        } catch (err) {
          console.warn(`${TAG} sendMessage failed`, err);
        }
      } catch (err) {
        console.warn(`${TAG} handler failed`, err);
      }
    })();
  });
  console.log(`${TAG} installed`);
}
function mergeMessages(prior, fresh) {
  const out = [...prior];
  for (const m of fresh) {
    const fp = fingerprint(m);
    const idx = out.findIndex((p) => fingerprint(p) === fp);
    if (idx >= 0) {
      const existing = out[idx];
      out[idx] = m.content.length >= existing.content.length ? m : existing;
    } else {
      out.push(m);
    }
  }
  return out;
}
function fingerprint(m) {
  return `${m.role}::${m.content.slice(0, 80).replace(/\s+/g, " ").trim()}`;
}
function deriveTitle(platform, messages) {
  const firstUser = messages.find((m) => m.role === "user")?.content ?? messages[0]?.content ?? "";
  const cleaned = firstUser.replace(/\s+/g, " ").trim();
  if (cleaned) return cleaned.length > 72 ? `${cleaned.slice(0, 71)}…` : cleaned;
  return `${platform[0].toUpperCase()}${platform.slice(1)} session`;
}
