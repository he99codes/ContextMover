import { s as startSessionCapture, w as waitForAnyElement, a as setPromptInputValue, e as extractMessageContent } from '../../shared-_GK_BFmD.js';
import '../../session-id-BlkLb76o.js';

console.log("[ContextForge] Claude content script loaded");
function scrapeMessages() {
  if (window.location.pathname === "/new") return [];
  const allTestIds = new Set(
    [...document.querySelectorAll("[data-testid]")].map((el) => el.dataset.testid ?? "").filter(Boolean)
  );
  console.log(`[ContextForge:claude] testids on page:`, [...allTestIds].sort().join(", "));
  const collected = [];
  const hasAsst = () => collected.some((e) => e.role === "assistant");
  document.querySelectorAll('[data-testid="user-message"]').forEach((el) => {
    if (isStreaming(el)) return;
    if (!el.parentElement?.closest('[data-testid="user-message"]'))
      collected.push({ el, role: "user" });
  });
  document.querySelectorAll(
    '[data-testid="ai-turn"], [data-testid="assistant-message"]'
  ).forEach((el) => {
    if (isStreaming(el)) return;
    if (el.closest('[data-testid="user-message"]')) return;
    if (el.parentElement?.closest('[data-testid="ai-turn"], [data-testid="assistant-message"]')) return;
    collected.push({ el, role: "assistant" });
  });
  console.log(`[ContextForge:claude] S1 testid: user=${collected.filter((e) => e.role === "user").length} asst=${collected.filter((e) => e.role === "assistant").length}`);
  if (!hasAsst()) {
    document.querySelectorAll('[data-testid="human-turn"], [data-testid="ai-turn"]').forEach((el) => {
      if (isStreaming(el)) return;
      if (el.parentElement?.closest('[data-testid="human-turn"], [data-testid="ai-turn"]')) return;
      const role = el.dataset.testid === "human-turn" ? "user" : "assistant";
      if (role === "assistant") collected.push({ el, role });
    });
    console.log(`[ContextForge:claude] S2 legacy: asst=${collected.filter((e) => e.role === "assistant").length}`);
  }
  if (!hasAsst()) {
    document.querySelectorAll('[class*="font-claude-message"]').forEach((el) => {
      if (isStreaming(el)) return;
      if (!el.parentElement?.closest('[class*="font-claude-message"]'))
        collected.push({ el, role: "assistant" });
    });
    console.log(`[ContextForge:claude] S3 class: asst=${collected.filter((e) => e.role === "assistant").length}`);
  }
  if (!hasAsst()) {
    document.querySelectorAll("h2.sr-only, h3.sr-only").forEach((h) => {
      const text = (h.textContent ?? "").trim().toLowerCase();
      const isAssistantHeading = text.startsWith("claude said") || text.startsWith("claude replied") || text.startsWith("assistant said") || /^claude[: ]/.test(text);
      if (!isAssistantHeading) return;
      const turn = h.parentElement ?? h;
      if (isStreaming(turn)) return;
      if (collected.some((entry) => entry.el === turn)) return;
      collected.push({ el: turn, role: "assistant" });
    });
    console.log(`[ContextForge:claude] S5 sr-only: asst=${collected.filter((e) => e.role === "assistant").length}`);
  }
  if (!hasAsst()) {
    const renderRoot = document.querySelector("[data-test-render-count]");
    const turnsContainer = renderRoot?.querySelector(":scope > .contents") ?? renderRoot;
    if (turnsContainer) {
      const dedup = new Set(collected.map((e) => e.el));
      const turns = [...turnsContainer.children];
      for (const turn of turns) {
        if (isStreaming(turn)) continue;
        if (dedup.has(turn)) continue;
        const isUserTurn = turn.querySelector('[data-user-message-bubble="true"]') || turn.querySelector('[data-testid="user-message"]') || turn.matches('[data-user-message-bubble="true"]') || turn.matches('[data-testid="user-message"]');
        if (isUserTurn) continue;
        const text = (turn.textContent ?? "").trim();
        if (text.length < 20) continue;
        collected.push({ el: turn, role: "assistant" });
        dedup.add(turn);
      }
      console.log(`[ContextForge:claude] S6 render-root: asst=${collected.filter((e) => e.role === "assistant").length}`);
    } else {
      console.log(`[ContextForge:claude] S6 render-root: no [data-test-render-count] found`);
    }
  }
  if (!hasAsst()) {
    const dedup = new Set(collected.map((e) => e.el));
    let actionBars = [
      ...document.querySelectorAll('[data-testid="action-bar-retry"]')
    ];
    if (actionBars.length === 0) {
      actionBars = [
        ...document.querySelectorAll('[data-testid="action-bar-copy"]')
      ].filter((el) => !el.closest('[data-testid="user-message"]'));
    }
    for (const bar of actionBars) {
      if (bar.closest('[data-testid="user-message"]')) continue;
      let cur = bar.parentElement;
      while (cur && cur !== document.body) {
        if (cur.matches('[data-testid="user-message"]')) break;
        const parent = cur.parentElement;
        if (!parent) break;
        const hasSiblingUser = [...parent.children].some(
          (s) => s !== cur && (s.matches('[data-testid="user-message"]') || !!s.querySelector('[data-testid="user-message"]'))
        );
        if (hasSiblingUser) {
          if (!dedup.has(cur) && !isStreaming(cur)) {
            const text = (cur.textContent ?? "").trim();
            if (text.length > 20) {
              collected.push({ el: cur, role: "assistant" });
              dedup.add(cur);
            }
          }
          break;
        }
        cur = cur.parentElement;
      }
    }
    console.log(`[ContextForge:claude] S7 action-bar: asst=${collected.filter((e) => e.role === "assistant").length}`);
  }
  if (!hasAsst() && collected.length > 0) {
    const firstUser = collected[0].el;
    let container = null;
    let cur = firstUser;
    const userCount = collected.filter((e) => e.role === "user").length;
    for (let depth = 0; depth < 15 && cur?.parentElement; depth++) {
      cur = cur.parentElement;
      if (cur.children.length >= userCount) {
        const children = [...cur.children];
        const hasNonUser = children.some(
          (child) => !child.matches('[data-testid="user-message"]') && !child.querySelector('[data-testid="user-message"]') && (child.textContent ?? "").trim().length > 20
        );
        if (hasNonUser) {
          container = cur;
          break;
        }
      }
    }
    if (container) {
      const dedup = new Set(collected.map((e) => e.el));
      const turns = [...container.children];
      console.log(`[ContextForge:claude] S4 structural: container has ${turns.length} children, userAnchors=${userCount}`);
      for (const turn of turns) {
        if (isStreaming(turn)) continue;
        if (turn.querySelector('[data-testid="user-message"]')) continue;
        if (turn.matches('[data-testid="user-message"]')) continue;
        if (dedup.has(turn)) continue;
        const text = (turn.textContent ?? "").trim();
        if (text.length > 20) {
          collected.push({ el: turn, role: "assistant" });
          dedup.add(turn);
        }
      }
      console.log(`[ContextForge:claude] S4 structural: asst=${collected.filter((e) => e.role === "assistant").length}`);
    } else {
      console.warn(`[ContextForge:claude] S4 structural: could not find conversation container`);
    }
  }
  if (collected.length === 0) return [];
  collected.sort((a, b) => {
    const pos = a.el.compareDocumentPosition(b.el);
    return pos & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
  });
  const messages = [];
  for (const { el, role } of collected) {
    const content = extractMessageContent(el);
    if (content) {
      messages.push({ role, content, timestamp: Date.now() });
    } else {
      console.warn(`[ContextForge:claude] empty content for role=${role} testid=${el.dataset.testid ?? "none"}`);
    }
  }
  const userC = messages.filter((m) => m.role === "user").length;
  const asstC = messages.filter((m) => m.role === "assistant").length;
  console.log("[CF:capture]", "claude", {
    total: messages.length,
    user: userC,
    assistant: asstC,
    preview: messages.map((m) => ({ role: m.role, len: m.content.length }))
  });
  if (asstC === 0 && userC > 0) {
    console.error(`[ContextForge:claude] ASSISTANT MESSAGES STILL MISSING after all strategies`);
  }
  return messages;
}
function isStreaming(el) {
  return el.hasAttribute("data-is-streaming") || el.closest("[data-is-streaming]") !== null;
}
startSessionCapture({
  platform: "claude",
  selectorOrElement: "main",
  scrapeMessages
});
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "INJECT_CONTEXT" && msg.platform === "claude") {
    void injectIntoClaudeInput(msg.prompt).then(sendResponse);
    return true;
  }
});
async function injectIntoClaudeInput(text) {
  const input = await waitForAnyElement([
    '.ProseMirror[contenteditable="true"]',
    // Claude ProseMirror editor
    '[contenteditable="true"][data-placeholder]',
    // placeholder-based selector
    '[contenteditable="true"][role="textbox"]',
    'fieldset [contenteditable="true"]',
    // Claude wraps input in fieldset
    'form [contenteditable="true"]',
    '[contenteditable="true"]'
    // last-resort
  ]);
  if (!input) return { ok: false, error: "Claude input box not found. Make sure a chat is open." };
  if (!setPromptInputValue(input, text)) {
    return { ok: false, error: "Claude input did not accept the text. Try reloading the tab." };
  }
  return { ok: true };
}
