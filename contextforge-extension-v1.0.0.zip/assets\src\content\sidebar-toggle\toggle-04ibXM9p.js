import { c as css } from '../../../toggle-CezpanlT.js';

const GUARD = "__cf_toggle_v1";
const w = window;
if (!w[GUARD]) {
  w[GUARD] = true;
  init();
}
function init() {
  let host = null;
  function ensureInjected() {
    if (host?.isConnected) return;
    host = inject();
  }
  ensureInjected();
  window.addEventListener("popstate", ensureInjected);
  const _push = history.pushState.bind(history);
  history.pushState = (...args) => {
    _push(...args);
    ensureInjected();
  };
}
function inject() {
  const host = document.createElement("div");
  host.id = "cf-toggle-host";
  Object.assign(host.style, {
    position: "fixed",
    top: "72px",
    right: "0",
    width: "0",
    height: "0",
    overflow: "visible",
    zIndex: "2147483647",
    pointerEvents: "none"
  });
  (document.documentElement ?? document.body).appendChild(host);
  const shadow = host.attachShadow({ mode: "open" });
  const styleEl = document.createElement("style");
  styleEl.textContent = css;
  shadow.appendChild(styleEl);
  const btn = document.createElement("button");
  btn.className = "cf-toggle";
  btn.setAttribute("aria-label", "Toggle ContextForge sidebar");
  btn.innerHTML = `
    <svg width="24" height="24" viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M10 2L3 6.5V13.5L10 18L17 13.5V6.5L10 2Z" fill="currentColor"/>
      <path d="M10 5.5L5.5 8V12L10 14.5L14.5 12V8L10 5.5Z" style="fill:var(--cf-inner)"/>
      <circle cx="10" cy="10" r="2.2" fill="currentColor"/>
    </svg>
    <span class="cf-dot cf-dot--idle" aria-hidden="true"></span>`;
  shadow.appendChild(btn);
  let isOpen = false;
  btn.addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "TOGGLE_SIDEBAR" }, (res) => {
      if (chrome.runtime.lastError) return;
      isOpen = res?.isOpen ?? !isOpen;
      btn.classList.toggle("cf-toggle--open", isOpen);
    });
  });
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type !== "CAPTURE_STATUS_UPDATE") return;
    const dot = shadow.querySelector(".cf-dot");
    if (dot) dot.className = `cf-dot cf-dot--${msg.status === "capturing" ? "active" : "idle"}`;
  });
  return host;
}
