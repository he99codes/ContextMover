(() => {
  const TAG = "[ContextForge:fetch]";
  const MAX_PAYLOAD_BYTES = 512e3;
  const CREDENTIAL_PATTERNS = [
    /Bearer\s+[A-Za-z0-9\-._~+/]+=*/g,
    /Authorization:\s*\S+/gi,
    /sk-[A-Za-z0-9]{20,}/g,
    /api[_-]?key[\s:=]+["']?[A-Za-z0-9\-._]{16,}["']?/gi
  ];
  function scrubCredentials(text) {
    let out = text;
    for (const re of CREDENTIAL_PATTERNS) {
      out = out.replace(re, "[CREDENTIAL REDACTED]");
    }
    return out;
  }
  const w = window;
  if (w.__contextForgeFetchInstalled) {
    console.log(`${TAG} already installed, skipping`);
    return;
  }
  w.__contextForgeFetchInstalled = true;
  const _originalFetch = window.fetch.bind(window);
  function urlOf(input) {
    try {
      if (typeof input === "string") return input;
      if (input instanceof URL) return input.toString();
      if (input instanceof Request) return input.url;
    } catch {
    }
    return "";
  }
  function detectPlatform(url) {
    if (!url) return null;
    if (url.includes("chatgpt.com/backend-api/conversation") || url.includes("chat.openai.com/backend-api/conversation")) return "chatgpt";
    if (url.includes("claude.ai/api") && /completion|append_message|chat_conversations/.test(url) || (url.includes("a-api.anthropic.com") || url.includes("api.anthropic.com")) && /\/v1\//.test(url)) return "claude";
    if (url.includes("gemini.google.com") && /GenerateContent|StreamGenerate|BardChatUi|assistant\.lamda/i.test(url)) return "gemini";
    if (url.includes("grok.com/api") && /chat|conversation|completion/i.test(url)) return "grok";
    if (url.includes("chat.deepseek.com/api") && /chat|completion|message/i.test(url)) return "deepseek";
    if (url.includes("perplexity.ai") && /\/api\/|search|ask|completions/i.test(url)) return "perplexity";
    return null;
  }
  function extractCodeBlocks(content) {
    const blocks = [];
    if (!content) return blocks;
    const re = /```([\w+\-./]*)\n?([\s\S]*?)```/g;
    let m;
    while ((m = re.exec(content)) !== null) {
      const language = (m[1] ?? "").trim();
      const code = (m[2] ?? "").replace(/\n+$/, "");
      if (code) blocks.push({ language, code });
    }
    return blocks;
  }
  function finalize(role, content, ts) {
    const trimmed = (content ?? "").trim();
    if (!trimmed) return null;
    const codeBlocks = extractCodeBlocks(trimmed);
    return {
      role,
      content: trimmed,
      timestamp: ts ?? Date.now(),
      ...codeBlocks.length > 0 ? { codeBlocks } : {}
    };
  }
  function dispatchCaptured(platform, messages) {
    if (!messages.length) return;
    try {
      window.dispatchEvent(
        new CustomEvent("contextforge:captured", {
          detail: { platform, messages }
        })
      );
    } catch (err) {
      console.warn(`${TAG} dispatch failed`, err);
    }
  }
  function parseChatGPT(text) {
    try {
      const byMsgId = /* @__PURE__ */ new Map();
      const lines = text.split(/\r?\n/);
      for (const raw of lines) {
        const line = raw.trim();
        if (!line.startsWith("data:")) continue;
        const payload = line.slice(5).trim();
        if (!payload || payload === "[DONE]") continue;
        let j;
        try {
          j = JSON.parse(payload);
        } catch {
          continue;
        }
        if (!j || typeof j !== "object") continue;
        const obj = j;
        const msg = obj.message ?? obj.v ?? null;
        if (msg && typeof msg === "object") {
          const id = String(msg.id ?? "_");
          const author = msg.author ?? {};
          const role = String(author.role ?? "");
          if (role !== "user" && role !== "assistant") continue;
          const c = msg.content ?? {};
          let chunk = "";
          if (Array.isArray(c.parts)) {
            chunk = c.parts.map((p) => typeof p === "string" ? p : "").join("");
          } else if (typeof c.text === "string") {
            chunk = c.text;
          }
          const cur = byMsgId.get(id) ?? { role, content: "", ts: Date.now() };
          if (chunk.length >= cur.content.length) cur.content = chunk;
          cur.role = role;
          byMsgId.set(id, cur);
        }
        if (Array.isArray(obj.choices)) {
          const ch = obj.choices[0];
          const delta = ch?.delta ?? {};
          const role = String(delta.role ?? "assistant");
          const piece = String(delta.content ?? "");
          if (piece) {
            const id = String(obj.id ?? "legacy");
            const cur = byMsgId.get(id) ?? { role, content: "", ts: Date.now() };
            cur.content += piece;
            byMsgId.set(id, cur);
          }
        }
      }
      const out = [];
      byMsgId.forEach((v) => {
        const fin = finalize(v.role, v.content, v.ts);
        if (fin) out.push(fin);
      });
      return out;
    } catch (err) {
      console.warn(`${TAG} parseChatGPT failed`, err);
      return [];
    }
  }
  function extractOpenAIUserPrompt(requestBody) {
    if (!requestBody) return null;
    try {
      const body = JSON.parse(requestBody);
      const msgs = body.messages;
      if (Array.isArray(msgs)) {
        for (let i = msgs.length - 1; i >= 0; i--) {
          const m = msgs[i];
          if (m?.role !== "user") continue;
          let text = "";
          if (typeof m.content === "string") {
            text = m.content;
          } else if (Array.isArray(m.content)) {
            text = m.content.filter((c) => c.type === "text").map((c) => String(c.text ?? "")).join("\n");
          }
          const fin = finalize("user", text);
          if (fin) return fin;
        }
      }
      const singleMsg = typeof body.message === "string" && body.message || typeof body.query === "string" && body.query || typeof body.q === "string" && body.q || "";
      if (singleMsg) {
        const fin = finalize("user", singleMsg);
        if (fin) return fin;
      }
    } catch {
    }
    return null;
  }
  function parseClaude(text, requestBody) {
    try {
      const lines = text.split(/\r?\n/);
      let curEvent = "";
      let acc = "";
      let role = "assistant";
      for (const raw of lines) {
        const line = raw.trim();
        if (!line) continue;
        if (line.startsWith("event:")) {
          curEvent = line.slice(6).trim();
          continue;
        }
        if (!line.startsWith("data:")) continue;
        const payload = line.slice(5).trim();
        if (!payload || payload === "[DONE]") continue;
        let j;
        try {
          j = JSON.parse(payload);
        } catch {
          continue;
        }
        if (!j || typeof j !== "object") continue;
        const obj = j;
        if (curEvent === "message_start" || obj.type === "message_start") {
          const m = obj.message;
          const r = String(m?.role ?? "assistant");
          if (r === "user" || r === "assistant") role = r;
          continue;
        }
        if (curEvent === "content_block_delta" || obj.type === "content_block_delta") {
          const delta = obj.delta;
          const t = String(delta?.text ?? "");
          acc += t;
          continue;
        }
        if (typeof obj.completion === "string") {
          acc += obj.completion;
        }
      }
      const results = [];
      const userMsg = extractOpenAIUserPrompt(requestBody ?? null);
      if (userMsg) results.push(userMsg);
      const fin = finalize(role, acc);
      if (fin) results.push(fin);
      return results;
    } catch (err) {
      console.warn(`${TAG} parseClaude failed`, err);
      return [];
    }
  }
  function parseGemini(text) {
    try {
      const cleaned = text.replace(/^\)\]\}'\s*/, "").trim();
      const messages = [];
      try {
        const j = JSON.parse(cleaned);
        const harvested = harvestGeminiText(j);
        if (harvested) {
          const fin2 = finalize("assistant", harvested);
          if (fin2) messages.push(fin2);
          return messages;
        }
      } catch {
      }
      const chunks = cleaned.split(/\n\d+\n/).filter(Boolean);
      let acc = "";
      for (const chunk of chunks) {
        try {
          const j = JSON.parse(chunk);
          const t = harvestGeminiText(j);
          if (t) acc += t;
        } catch {
        }
      }
      const fin = finalize("assistant", acc);
      if (fin) messages.push(fin);
      return messages;
    } catch (err) {
      console.warn(`${TAG} parseGemini failed`, err);
      return [];
    }
  }
  function harvestGeminiText(node, depth = 0) {
    if (depth > 12 || node == null) return "";
    if (typeof node === "string") {
      if (node.length < 10) return "";
      if (/^[a-zA-Z0-9_-]+$/.test(node)) return "";
      if (/^[\d.eE+-]+$/.test(node)) return "";
      return node.includes(" ") ? node : "";
    }
    if (Array.isArray(node)) {
      let best = "";
      for (const child of node) {
        const t = harvestGeminiText(child, depth + 1);
        if (t.length > best.length) best = t;
      }
      return best;
    }
    if (typeof node === "object") {
      const obj = node;
      const candidates = obj.candidates;
      if (Array.isArray(candidates) && candidates.length > 0) {
        const first = candidates[0];
        const content = first?.content;
        const parts = content?.parts;
        if (Array.isArray(parts)) {
          const joined = parts.map((p) => p && typeof p === "object" ? String(p.text ?? "") : "").join("");
          if (joined.trim()) return joined;
        }
      }
      let best = "";
      for (const v of Object.values(obj)) {
        const t = harvestGeminiText(v, depth + 1);
        if (t.length > best.length) best = t;
      }
      return best;
    }
    return "";
  }
  function parseGrok(text, requestBody) {
    try {
      const lines = text.split(/\r?\n/);
      let acc = "";
      for (const raw of lines) {
        const line = raw.trim();
        if (!line) continue;
        const payload = line.startsWith("data:") ? line.slice(5).trim() : line;
        if (!payload || payload === "[DONE]") continue;
        let j;
        try {
          j = JSON.parse(payload);
        } catch {
          continue;
        }
        if (!j || typeof j !== "object") continue;
        const obj = j;
        const result = obj.result ?? {};
        const response = result.response ?? {};
        if (Array.isArray(obj.choices)) {
          const ch = obj.choices[0];
          const delta = ch?.delta ?? {};
          if (typeof delta.content === "string") {
            acc += delta.content;
            continue;
          }
        }
        const piece = typeof obj.token === "string" && obj.token || typeof obj.content === "string" && obj.content || typeof response.token === "string" && response.token || typeof response.message === "string" && response.message || typeof result.token === "string" && result.token || "";
        if (piece) acc += piece;
      }
      const results = [];
      const userMsg = extractOpenAIUserPrompt(requestBody ?? null);
      if (userMsg) results.push(userMsg);
      const fin = finalize("assistant", acc);
      if (fin) results.push(fin);
      return results;
    } catch (err) {
      console.warn(`${TAG} parseGrok failed`, err);
      return [];
    }
  }
  function parseDeepSeek(text, requestBody) {
    try {
      const results = [];
      const userMsg = extractOpenAIUserPrompt(requestBody ?? null);
      if (userMsg) results.push(userMsg);
      const asstMsgs = parseChatGPT(text).filter((m) => m.role === "assistant");
      results.push(...asstMsgs);
      return results;
    } catch (err) {
      console.warn(`${TAG} parseDeepSeek failed`, err);
      return [];
    }
  }
  function parsePerplexity(text, requestBody) {
    try {
      const lines = text.split(/\r?\n/);
      let acc = "";
      let finalAnswer = "";
      for (const raw of lines) {
        const line = raw.trim();
        if (!line) continue;
        const payload = line.startsWith("data:") ? line.slice(5).trim() : line;
        if (!payload || payload === "[DONE]") continue;
        let j;
        try {
          j = JSON.parse(payload);
        } catch {
          continue;
        }
        if (!j || typeof j !== "object") continue;
        const obj = j;
        if (typeof obj.answer === "string" && obj.answer.length > finalAnswer.length) {
          finalAnswer = obj.answer;
        }
        if (typeof obj.chunk === "string") {
          acc += obj.chunk;
          continue;
        }
        if (typeof obj.text === "string") {
          acc += obj.text;
          continue;
        }
        if (Array.isArray(obj.choices)) {
          const ch = obj.choices[0];
          const delta = ch?.delta ?? {};
          if (typeof delta.content === "string") {
            acc += delta.content;
            continue;
          }
          const msg = ch?.message;
          if (typeof msg?.content === "string") {
            acc += msg.content;
            continue;
          }
        }
      }
      const assistantText = finalAnswer || acc;
      const results = [];
      const userMsg = extractOpenAIUserPrompt(requestBody ?? null);
      if (userMsg) results.push(userMsg);
      const fin = finalize("assistant", assistantText);
      if (fin) results.push(fin);
      return results;
    } catch (err) {
      console.warn(`${TAG} parsePerplexity failed`, err);
      return [];
    }
  }
  async function handleAIResponse(platform, response, requestBody) {
    try {
      const text = await response.text();
      if (!text) return;
      if (text.length > MAX_PAYLOAD_BYTES) {
        console.warn(`${TAG} ${platform}: payload exceeds ${MAX_PAYLOAD_BYTES} bytes — dropped`);
        return;
      }
      let messages = [];
      switch (platform) {
        case "chatgpt":
          messages = parseChatGPT(text);
          break;
        case "claude":
          messages = parseClaude(text, requestBody);
          break;
        case "gemini":
          messages = parseGemini(text);
          break;
        case "grok":
          messages = parseGrok(text, requestBody);
          break;
        case "deepseek":
          messages = parseDeepSeek(text, requestBody);
          break;
        case "perplexity":
          messages = parsePerplexity(text, requestBody);
          break;
      }
      if (messages.length === 0) {
        console.log(`${TAG} ${platform}: no messages parsed (body length=${text.length})`);
        return;
      }
      messages = messages.filter((m) => m.role && m.content && m.content.length > 0);
      if (messages.length === 0) return;
      messages = messages.map((m) => ({ ...m, content: scrubCredentials(m.content) }));
      console.log(`${TAG} ${platform}: parsed ${messages.length} msg(s)`);
      dispatchCaptured(platform, messages);
    } catch (err) {
      console.warn(`${TAG} handleAIResponse failed`, err);
    }
  }
  try {
    window.fetch = async function(input, init) {
      let requestBodyText = null;
      try {
        const url = urlOf(input);
        const earlyPlatform = detectPlatform(url);
        if (earlyPlatform && earlyPlatform !== "gemini" && init?.body) {
          requestBodyText = typeof init.body === "string" ? init.body : init.body instanceof URLSearchParams ? init.body.toString() : null;
        }
      } catch {
      }
      const response = await _originalFetch(input, init);
      try {
        const url = urlOf(input);
        const platform = detectPlatform(url);
        if (platform) {
          const clone = response.clone();
          const body = requestBodyText;
          queueMicrotask(() => {
            void handleAIResponse(platform, clone, body);
          });
        }
      } catch (err) {
        console.warn(`${TAG} intercept side-effect failed (response unaffected)`, err);
      }
      return response;
    };
    console.log(`${TAG} window.fetch override installed`);
  } catch (err) {
    console.error(`${TAG} CRITICAL: failed to install fetch override; restoring original`, err);
    try {
      window.fetch = _originalFetch;
    } catch {
    }
  }
  try {
    let isPerplexityURL2 = function(url) {
      try {
        const host = new URL(url).hostname;
        return host === "perplexity.ai" || host.endsWith(".perplexity.ai");
      } catch {
        return /^https?:\/\/(?:[\w-]+\.)?perplexity\.ai(?:\/|$)/.test(url);
      }
    }, handlePerplexityWSMessage2 = function(data) {
      if (typeof data !== "string") return;
      if (!data.startsWith("42")) return;
      try {
        let jsonStr = data.slice(2);
        if (jsonStr.startsWith("/")) {
          const comma = jsonStr.indexOf(",");
          if (comma === -1) return;
          jsonStr = jsonStr.slice(comma + 1);
        }
        const arr = JSON.parse(jsonStr);
        if (!Array.isArray(arr) || arr.length < 2) return;
        const eventName = String(arr[0]);
        const payload = arr[1];
        if (!payload || typeof payload !== "object") return;
        const status = String(payload.status ?? "");
        const isFinal = status === "completed" || status === "done" || status === "final" || /complet|finish/i.test(eventName);
        if (!isFinal) return;
        const assistantText = typeof payload.text === "string" && payload.text || typeof payload.answer === "string" && payload.answer || typeof payload.output === "string" && payload.output || "";
        const userText = typeof payload.query_str === "string" && payload.query_str || typeof payload.query === "string" && payload.query || "";
        const results = [];
        const userMsg = finalize("user", userText);
        if (userMsg) results.push(userMsg);
        const asstMsg = finalize("assistant", assistantText);
        if (asstMsg) results.push(asstMsg);
        if (results.length > 0) {
          console.log(`${TAG} perplexity WS: captured ${results.length} msg(s) via ${eventName}`);
          dispatchCaptured("perplexity", results);
        }
      } catch {
      }
    }, PatchedWebSocket2 = function(url, protocols) {
      const ws = protocols != null ? new OrigWS(url, protocols) : new OrigWS(url);
      if (isPerplexityURL2(url)) {
        ws.addEventListener("message", (ev) => {
          try {
            handlePerplexityWSMessage2(ev.data);
          } catch {
          }
        });
        console.log(`${TAG} perplexity WS: attached listener on ${url}`);
      }
      return ws;
    };
    var isPerplexityURL = isPerplexityURL2, handlePerplexityWSMessage = handlePerplexityWSMessage2, PatchedWebSocket = PatchedWebSocket2;
    const _OriginalWS = window.WebSocket;
    const OrigWS = _OriginalWS;
    PatchedWebSocket2.prototype = _OriginalWS.prototype;
    Object.setPrototypeOf(PatchedWebSocket2, _OriginalWS);
    PatchedWebSocket2.CONNECTING = _OriginalWS.CONNECTING;
    PatchedWebSocket2.OPEN = _OriginalWS.OPEN;
    PatchedWebSocket2.CLOSING = _OriginalWS.CLOSING;
    PatchedWebSocket2.CLOSED = _OriginalWS.CLOSED;
    window.WebSocket = PatchedWebSocket2;
    console.log(`${TAG} WebSocket override installed (Perplexity socket.io)`);
  } catch (err) {
    console.warn(`${TAG} WebSocket override failed (non-critical, Perplexity DOM fallback still active)`, err);
  }
})();
