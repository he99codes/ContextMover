import { s as startSessionCapture, w as waitForAnyElement, a as setPromptInputValue, e as extractMessageContent } from './shared-_GK_BFmD.js';
import './session-id-BlkLb76o.js';

function isStreaming(el) {
  return el.classList.contains("result-streaming") || el.querySelector(".result-streaming") !== null || el.closest("[data-is-streaming]") !== null || el.closest(".loading") !== null;
}
function scrapeMessages() {
  const messages = [];
  document.querySelectorAll("user-query").forEach((container) => {
    if (isStreaming(container)) return;
    const el = container.querySelector(".query-text");
    if (!el) return;
    const content = extractMessageContent(el);
    if (content) messages.push({ role: "user", content, timestamp: Date.now() });
  });
  document.querySelectorAll("model-response").forEach((container) => {
    if (isStreaming(container)) return;
    const el = container.querySelector(".response-content");
    if (!el) return;
    const content = extractMessageContent(el);
    if (content) messages.push({ role: "assistant", content, timestamp: Date.now() });
  });
  const userCount = messages.filter((m) => m.role === "user").length;
  const asstCount = messages.filter((m) => m.role === "assistant").length;
  console.log("[CF:capture]", "gemini", {
    total: messages.length,
    user: userCount,
    assistant: asstCount,
    preview: messages.map((m) => ({ role: m.role, len: m.content.length }))
  });
  if (asstCount === 0 && userCount > 0) {
    console.error(`[ContextForge:gemini] ASSISTANT MESSAGES MISSING`);
  }
  return messages;
}
startSessionCapture({
  platform: "gemini",
  selectorOrElement: "chat-window, main",
  scrapeMessages
});
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "INJECT_CONTEXT" && msg.platform === "gemini") {
    void injectIntoGeminiInput(msg.prompt).then(sendResponse);
    return true;
  }
});
async function injectIntoGeminiInput(text) {
  const input = await waitForAnyElement([
    "rich-textarea [contenteditable='true']",
    // Gemini Angular component
    "rich-textarea p",
    // inner paragraph element
    "[contenteditable='true'][role='textbox']",
    "[contenteditable='true'][aria-label]",
    // labelled contenteditable
    "textarea:not([readonly])",
    "[contenteditable='true']"
    // last-resort
  ]);
  if (!input) return { ok: false, error: "Gemini input box not found. Make sure a chat is open." };
  if (!setPromptInputValue(input, text)) {
    return { ok: false, error: "Gemini input did not accept the text. Try reloading the tab." };
  }
  return { ok: true };
}
