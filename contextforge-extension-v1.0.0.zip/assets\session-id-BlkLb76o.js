const URL_MAP_KEY = "cf:urlMap";
function urlKeyFromHref(platform, href) {
  let path = "";
  try {
    const u = new URL(href);
    path = `${u.hostname}${u.pathname}${u.search}`.replace(/\/$/, "");
  } catch {
    path = href;
  }
  return `${platform}::${path}`;
}
function legacySessionId(platform, href) {
  let path = "";
  try {
    const u = new URL(href);
    path = `${u.hostname}${u.pathname}${u.search}`.replace(/\/$/, "");
  } catch {
    path = href;
  }
  let hash = 7;
  for (let i = 0; i < path.length; i++) {
    hash = hash * 31 + path.charCodeAt(i) >>> 0;
  }
  return `${platform}-${hash.toString(36)}`;
}
function mintRandomSessionId(platform) {
  const raw = (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function" ? crypto.randomUUID() : `${Date.now().toString(36)}${Math.random().toString(36).slice(2)}`).replace(/-/g, "");
  return `${platform}-${raw.slice(0, 10)}`;
}
async function loadMap() {
  try {
    const stored = await chrome.storage.local.get(URL_MAP_KEY);
    const map = stored?.[URL_MAP_KEY];
    return map && typeof map === "object" ? map : {};
  } catch {
    return {};
  }
}
async function saveMap(map) {
  try {
    await chrome.storage.local.set({ [URL_MAP_KEY]: map });
  } catch {
  }
}
async function resolveSessionId(platform, href, legacyChecker) {
  const key = urlKeyFromHref(platform, href);
  const map = await loadMap();
  if (map[key]) return map[key];
  let id = null;
  if (legacyChecker) {
    const candidate = legacySessionId(platform, href);
    try {
      const exists = await legacyChecker(candidate);
      if (exists) id = candidate;
    } catch {
    }
  }
  if (!id) id = mintRandomSessionId(platform);
  map[key] = id;
  await saveMap(map);
  return id;
}
async function forgetSession(sessionId) {
  const map = await loadMap();
  let changed = false;
  for (const k of Object.keys(map)) {
    if (map[k] === sessionId) {
      delete map[k];
      changed = true;
    }
  }
  if (changed) await saveMap(map);
}
function makeLegacyChecker() {
  return async (legacyId) => {
    try {
      const response = await chrome.runtime.sendMessage({
        type: "SESSION_EXISTS",
        sessionId: legacyId
      });
      return Boolean(response?.exists);
    } catch {
      return false;
    }
  };
}

export { forgetSession as f, makeLegacyChecker as m, resolveSessionId as r };
