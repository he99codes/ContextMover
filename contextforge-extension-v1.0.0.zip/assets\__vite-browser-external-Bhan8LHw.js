const sharp = {};

const ONNX_NODE = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: sharp
}, Symbol.toStringTag, { value: 'Module' }));

export { ONNX_NODE as O, sharp as s };
